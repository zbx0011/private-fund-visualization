'use client'

import { useState, useEffect } from 'react'
import { MetricCard } from '@/components/ui/metric-card'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { YieldCurveChart } from '@/components/charts/YieldCurveChart'
import { PieChart, Pie, Cell, Tooltip, Legend, ResponsiveContainer } from 'recharts'
import { ProfitAnalysisChart } from '@/components/charts/ProfitAnalysisChart'

const STRATEGY_TYPES = [
    '指增',
    '中性',
    'CTA',
    'T0',
    '套利',
    '量选',
    '混合',
    '期权',
    '择时对冲',
    '可转债'
]

interface OverviewModuleProps {
    initialData?: any
    initialLoading?: boolean
    initialError?: string | null
}

export function OverviewModule({ initialData, initialLoading = false, initialError }: OverviewModuleProps) {
    const [data, setData] = useState<any>(initialData)
    const [loading, setLoading] = useState(initialLoading)
    const [selectedStrategy, setSelectedStrategy] = useState<string>('all')

    // Fetch full history data when component mounts
    useEffect(() => {
        const loadFullData = async () => {
            try {
                setLoading(true)
                const res = await fetch('/api/funds?type=excluded-fof&includeHistory=true')
                const json = await res.json()
                if (json.success) {
                    const { funds, strategyStats, managerStats } = json.data

                    // Filter funds by status
                    // 只要不是已赎回状态，都视为正常参与计算
                    const normalFunds = funds.filter((f: any) => f.status !== '已赎回')

                    // Calculate aggregated metrics
                    // 1. 总规模: 产品数据的成本列的总和 (仅计算正常状态产品，排除已赎回)
                    const totalAssets = normalFunds.reduce((sum: number, f: any) => sum + (f.cost || 0), 0)

                    // 2. 总日均资金占用: 飞书多维表格的私募盈亏一览表的日均资金占用列的总和 (包含所有产品)
                    const totalDailyCapitalUsage = funds.reduce((sum: number, f: any) => sum + (f.daily_capital_usage || 0), 0)

                    // 3. 今日收益: 产品数据的本日收益列的总和 (仅计算正常状态产品)
                    const todayReturn = normalFunds.reduce((sum: number, f: any) => sum + (f.daily_pnl || 0), 0)

                    // 4. 本周收益率: 飞书多维表格私募盈亏一览表的本周收益列的总和/总规模*100%
                    // 注意：这里也应该只计算正常产品的本周收益，以与总规模匹配
                    const totalWeeklyPnl = normalFunds.reduce((sum: number, f: any) => sum + (f.weekly_pnl || 0), 0)
                    const weeklyReturn = totalAssets ? totalWeeklyPnl / totalAssets : 0

                    // 5. 本年收益率: 飞书多维表格私募盈亏一览表的本年收益列的总和/总日均资金占用*100%
                    const totalYearlyPnl = funds.reduce((sum: number, f: any) => sum + (f.yearly_pnl || 0), 0)
                    const annualReturn = totalDailyCapitalUsage ? totalYearlyPnl / totalDailyCapitalUsage : 0

                    // Map strategy stats
                    const strategyData = strategyStats
                        .filter((s: any) => !['择时', '宏观'].includes(s.strategy))
                        .map((s: any) => ({
                            strategy: s.strategy,
                            value: s.total_cost || 0,
                            count: s.fund_count
                        }))

                    setData({
                        funds,
                        strategyStats,
                        managerStats,
                        totalAssets,
                        totalDailyCapitalUsage,
                        todayReturn,
                        weeklyReturn,
                        annualReturn,
                        strategyData
                    })
                }
            } catch (err) {
                console.error('Failed to load full history:', err)
            } finally {
                setLoading(false)
            }
        }
        loadFullData()
    }, [])

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">正在加载数据...</p>
                </div>
            </div>
        )
    }

    if (initialError || !data) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="text-center">
                    <div className="text-red-600 text-6xl mb-4">⚠️</div>
                    <p className="text-gray-600 text-lg mb-4">{initialError || '数据加载失败'}</p>
                </div>
            </div>
        )
    }

    // Helper to get the Friday of the week for a given date
    const getWeekEndingDate = (dateStr: string) => {
        const date = new Date(dateStr)
        const day = date.getDay()
        const diff = date.getDate() - day + (day === 0 ? -2 : 5) // Adjust to Friday
        const friday = new Date(date.setDate(diff))
        return friday.toISOString().split('T')[0]
    }

    // Process data for the chart
    const getChartData = () => {
        if (!data.funds) return { chartData: [], series: [] }

        // Filter funds based on selected strategy
        const filteredFunds = selectedStrategy === 'all'
            ? data.funds
            : data.funds.filter((f: any) => f.strategy === selectedStrategy)

        // ---------------------------------------------------------
        // Scenario 1: "All Strategies" - Aggregate by Strategy
        // ---------------------------------------------------------
        if (selectedStrategy === 'all') {
            // We will collect data into a map: Date -> { Strategy -> { sumReturn, sumYearly, count } }
            const weeklyMap = new Map<string, {
                date: string,
                strategies: Map<string, { sumReturn: number, sumYearly: number, count: number }>
            }>()

            data.funds.forEach((fund: any) => {
                if (!fund.strategy) return
                if (['择时', '宏观'].includes(fund.strategy)) return
                if (!fund.history || fund.history.length === 0) return

                // Filter for 2025 data
                const history2025 = fund.history
                    .filter((h: any) => h.date >= '2025-01-01')
                    .sort((a: any, b: any) => a.date.localeCompare(b.date))

                if (history2025.length === 0) return

                const baseNav = history2025[0].cumulative_nav

                // 1. Identify the value for each week for this fund (take the last available day of the week)
                const fundWeeklyValues = new Map<string, any>()
                history2025.forEach((h: any) => {
                    const dateStr = h.date.split('T')[0]
                    const weekDate = getWeekEndingDate(dateStr)

                    // Overwrite: later days in the week will replace earlier ones
                    fundWeeklyValues.set(weekDate, {
                        cumulative_nav: h.cumulative_nav,
                        daily_return: h.daily_return || 0
                    })
                })

                // 2. Add this fund's weekly values to the global aggregation
                fundWeeklyValues.forEach((val, weekDate) => {
                    if (!weeklyMap.has(weekDate)) {
                        weeklyMap.set(weekDate, { date: weekDate, strategies: new Map() })
                    }
                    const weekData = weeklyMap.get(weekDate)!

                    if (!weekData.strategies.has(fund.strategy)) {
                        weekData.strategies.set(fund.strategy, { sumReturn: 0, sumYearly: 0, count: 0 })
                    }
                    const stratStats = weekData.strategies.get(fund.strategy)!

                    const normalizedReturn = baseNav ? (val.cumulative_nav - baseNav) / baseNav : 0

                    stratStats.sumReturn += normalizedReturn
                    stratStats.sumYearly += normalizedReturn
                    stratStats.count += 1
                })
            })

            // 3. Flatten map to chartData array
            const chartData = Array.from(weeklyMap.values())
                .map(item => {
                    const point: any = { date: item.date }
                    item.strategies.forEach((stats, strategy) => {
                        point[strategy] = stats.sumReturn / stats.count
                        point[`${strategy}_yearly`] = stats.sumYearly / stats.count
                    })
                    return point
                })
                .sort((a, b) => a.date.localeCompare(b.date))

            // 4. Build Series
            const strategyColors: Record<string, string> = {
                '指增': '#3b82f6',
                '中性': '#10b981',
                'CTA': '#f59e0b',
                'T0': '#8b5cf6',
                '套利': '#ec4899',
                '量选': '#06b6d4',
                '混合': '#f97316',
                '期权': '#6366f1',
                '择时对冲': '#8b5cf6',
                '可转债': '#d946ef'
            }

            const series = Array.from(new Set(data.funds.map((f: any) => f.strategy).filter(Boolean))).map((strategy: any) => ({
                id: strategy,
                name: strategy,
                color: strategyColors[strategy] || `hsl(${Math.random() * 360}, 70%, 50%)`,
                strokeWidth: 2.5,
                yearlyKey: `${strategy}_yearly`
            }))

            return { chartData, series }
        }

        // ---------------------------------------------------------
        // Scenario 2: Specific Strategy - Individual Funds
        // ---------------------------------------------------------
        const weeklyMap = new Map<string, any>()

        filteredFunds.forEach((fund: any) => {
            if (!fund.history || fund.history.length === 0) return

            const history2025 = fund.history
                .filter((h: any) => h.date >= '2025-01-01')
                .sort((a: any, b: any) => a.date.localeCompare(b.date))

            if (history2025.length === 0) return

            const baseNav = history2025[0].cumulative_nav

            // Group by week
            history2025.forEach((h: any) => {
                const dateStr = h.date.split('T')[0]
                const weekDate = getWeekEndingDate(dateStr)

                if (!weeklyMap.has(weekDate)) {
                    weeklyMap.set(weekDate, { date: weekDate })
                }
                const point = weeklyMap.get(weekDate)

                // Use the latest value for the week (since we iterate sorted by date, this naturally happens)
                const normalizedReturn = baseNav ? (h.cumulative_nav - baseNav) / baseNav : 0

                point[fund.record_id] = normalizedReturn
                point[`${fund.record_id}_yearly`] = normalizedReturn
            })
        })

        const chartData = Array.from(weeklyMap.values()).sort((a, b) => a.date.localeCompare(b.date))

        const series = filteredFunds.map((fund: any) => ({
            id: fund.record_id,
            name: fund.name,
            color: `hsl(${Math.random() * 360}, 70%, 50%)`,
            strokeWidth: 2,
            yearlyKey: `${fund.record_id}_yearly`
        }))

        return { chartData, series }
    }

    const { chartData, series } = getChartData()

    return (
        <div className="space-y-8">
            {/* 1. 核心指标 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-6">
                <MetricCard
                    title="总规模"
                    value={data.totalAssets}
                    format="currency"
                    className="col-span-1"
                />
                <MetricCard
                    title="总日均资金占用"
                    value={data.totalDailyCapitalUsage}
                    format="currency"
                    className="col-span-1"
                />
                <MetricCard
                    title="今日收益"
                    value={data.todayReturn}
                    format="currency"
                    className="col-span-1"
                />
                <MetricCard
                    title="本周收益率"
                    value={data.weeklyReturn}
                    format="percent"
                    className="col-span-1"
                />
                <MetricCard
                    title="本年收益率"
                    value={data.annualReturn}
                    format="percent"
                    className="col-span-1"
                />
            </div>

            {/* 2. 近期事件提示 */}
            <Card>
                <CardHeader className="py-3">
                    <CardTitle className="text-base">🔔 近期事件提示</CardTitle>
                </CardHeader>
                <CardContent className="py-3">
                    <div className="flex flex-col sm:flex-row gap-4">
                        <div className="px-3 py-1 bg-yellow-50 border border-yellow-200 rounded-md text-yellow-800 text-sm flex items-center">
                            <span className="font-bold mr-2">提示:</span> 景林资产净值更新延迟 (2025-11-20)
                        </div>
                        <div className="px-3 py-1 bg-blue-50 border border-blue-200 rounded-md text-blue-800 text-sm flex items-center">
                            <span className="font-bold mr-2">信息:</span> 新增 3 只基金产品 (2025-11-19)
                        </div>
                    </div>
                </CardContent>
            </Card>

            {/* 3. 收益比较 */}
            <ProfitAnalysisChart funds={data.funds} />

            {/* 4. 收益率曲线 */}
            <Card>
                <CardHeader>
                    <div className="flex flex-col space-y-4 w-full">
                        <div className="flex items-center justify-between">
                            <CardTitle>📈 收益率曲线</CardTitle>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            <button
                                onClick={() => setSelectedStrategy('all')}
                                className={`px-3 py-1 text-sm rounded-full transition-colors ${selectedStrategy === 'all'
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                    }`}
                            >
                                全部策略
                            </button>
                            {STRATEGY_TYPES.map((strategy) => (
                                <button
                                    key={strategy}
                                    onClick={() => setSelectedStrategy(strategy)}
                                    className={`px-3 py-1 text-sm rounded-full transition-colors ${selectedStrategy === strategy
                                        ? 'bg-blue-600 text-white'
                                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                        }`}
                                >
                                    {strategy}
                                </button>
                            ))}
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <YieldCurveChart data={chartData} series={series} />
                </CardContent>
            </Card>

            {/* 5. 策略分布 */}
            <Card>
                <CardHeader>
                    <CardTitle>🥧 策略分布</CardTitle>
                </CardHeader>
                <CardContent>
                    {data.strategyData && data.strategyData.length > 0 ? (
                        <div className="h-[300px]">
                            <ResponsiveContainer width="100%" height="100%">
                                <PieChart>
                                    <Pie
                                        data={data.strategyData}
                                        cx="50%"
                                        cy="50%"
                                        labelLine={false}
                                        label={({ name, percent }: any) => `${name} ${(percent * 100).toFixed(0)}%`}
                                        outerRadius={100}
                                        fill="#8884d8"
                                        dataKey="value"
                                        nameKey="strategy"
                                    >
                                        {data.strategyData.map((entry: any, index: number) => (
                                            <Cell key={`cell-${index}`} fill={['#3b82f6', '#10b981', '#f59e0b', '#8b5cf6', '#ec4899', '#06b6d4', '#f97316', '#6366f1', '#8b5cf6', '#d946ef'][index % 10]} />
                                        ))}
                                    </Pie>
                                    <Tooltip
                                        formatter={(value: number, name: string) => [`¥${(value / 10000).toFixed(2)}万`, name]}
                                    />
                                    <Legend wrapperStyle={{ fontSize: '12px' }} />
                                </PieChart>
                            </ResponsiveContainer>
                        </div>
                    ) : (
                        <div className="h-[300px] flex items-center justify-center text-gray-400">
                            暂无策略分布数据
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    )
}
