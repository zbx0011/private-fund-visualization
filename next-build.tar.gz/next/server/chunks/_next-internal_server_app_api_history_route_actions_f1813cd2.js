module.exports=[17541,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_history_route_actions_f1813cd2.js.map