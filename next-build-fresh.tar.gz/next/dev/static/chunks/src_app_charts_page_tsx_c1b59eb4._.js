(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_aed4232c._.js",
  "static/chunks/node_modules_recharts_es6_2e6e8990._.js",
  "static/chunks/node_modules_ea208237._.js"
],
    source: "dynamic"
});
