module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/better-sqlite3 [external] (better-sqlite3, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("better-sqlite3", () => require("better-sqlite3"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[project]/src/lib/external-monitor-db.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "countExternalMonitorRecords",
    ()=>countExternalMonitorRecords,
    "getExternalMonitorRecords",
    ()=>getExternalMonitorRecords,
    "insertExternalMonitorRecord",
    ()=>insertExternalMonitorRecord
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$better$2d$sqlite3__$5b$external$5d$__$28$better$2d$sqlite3$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/better-sqlite3 [external] (better-sqlite3, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const dbPath = __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["default"].join(process.cwd(), 'data', 'funds.db');
const db = new __TURBOPACK__imported__module__$5b$externals$5d2f$better$2d$sqlite3__$5b$external$5d$__$28$better$2d$sqlite3$2c$__cjs$29$__["default"](dbPath);
// Initialize external_monitor table
const initExternalMonitorTable = ()=>{
    db.exec(`
        CREATE TABLE IF NOT EXISTS external_monitor (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            date TEXT NOT NULL,
            title TEXT NOT NULL,
            summary TEXT,
            source TEXT,
            related_enterprise TEXT,
            importance TEXT,
            sentiment TEXT,
            level1_category TEXT,
            level2_category TEXT,
            url TEXT,
            created_at DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    `);
};
function insertExternalMonitorRecord(record) {
    const stmt = db.prepare(`
        INSERT INTO external_monitor (
            date, title, summary, source, related_enterprise,
            importance, sentiment, level1_category, level2_category, url
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `);
    return stmt.run(record.date, record.title, record.summary || null, record.source || null, record.related_enterprise || null, record.importance || null, record.sentiment || null, record.level1_category || null, record.level2_category || null, record.url || null);
}
function getExternalMonitorRecords(filters) {
    let query = 'SELECT * FROM external_monitor WHERE 1=1';
    const params = [];
    if (filters?.importance) {
        query += ' AND importance = ?';
        params.push(filters.importance);
    }
    if (filters?.sentiment) {
        query += ' AND sentiment = ?';
        params.push(filters.sentiment);
    }
    if (filters?.enterprise) {
        query += ' AND related_enterprise LIKE ?';
        params.push(`%${filters.enterprise}%`);
    }
    query += ' ORDER BY date DESC';
    if (filters?.limit) {
        query += ' LIMIT ?';
        params.push(filters.limit);
    }
    if (filters?.offset) {
        query += ' OFFSET ?';
        params.push(filters.offset);
    }
    const stmt = db.prepare(query);
    return stmt.all(...params);
}
function countExternalMonitorRecords(filters) {
    let query = 'SELECT COUNT(*) as count FROM external_monitor WHERE 1=1';
    const params = [];
    if (filters?.importance) {
        query += ' AND importance = ?';
        params.push(filters.importance);
    }
    if (filters?.sentiment) {
        query += ' AND sentiment = ?';
        params.push(filters.sentiment);
    }
    if (filters?.enterprise) {
        query += ' AND related_enterprise LIKE ?';
        params.push(`%${filters.enterprise}%`);
    }
    const stmt = db.prepare(query);
    const result = stmt.get(...params);
    return result.count;
}
// Initialize table on module load
initExternalMonitorTable();
}),
"[project]/src/app/api/monitor/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "dynamic",
    ()=>dynamic
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$external$2d$monitor$2d$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/external-monitor-db.ts [app-route] (ecmascript)");
;
const dynamic = 'force-dynamic';
;
async function GET(request) {
    try {
        const { searchParams } = new URL(request.url);
        const filters = {
            importance: searchParams.get('importance') || undefined,
            sentiment: searchParams.get('sentiment') || undefined,
            enterprise: searchParams.get('enterprise') || undefined,
            limit: Number(searchParams.get('limit')) || 100,
            offset: Number(searchParams.get('offset')) || 0
        };
        const records = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$external$2d$monitor$2d$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getExternalMonitorRecords"])(filters);
        const total = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$external$2d$monitor$2d$db$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["countExternalMonitorRecords"])(filters);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: records,
            total,
            page: Math.floor(filters.offset / filters.limit) + 1,
            pageSize: filters.limit
        });
    } catch (error) {
        console.error('External Monitor API Error:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: 'Failed to fetch external monitor data'
        }, {
            status: 500
        });
    }
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__5c733cef._.js.map