module.exports = [
"[externals]/next/dist/compiled/next-server/app-route-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-route-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-route-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/@opentelemetry/api [external] (next/dist/compiled/@opentelemetry/api, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/@opentelemetry/api", () => require("next/dist/compiled/@opentelemetry/api"));

module.exports = mod;
}),
"[externals]/next/dist/compiled/next-server/app-page-turbo.runtime.dev.js [external] (next/dist/compiled/next-server/app-page-turbo.runtime.dev.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js", () => require("next/dist/compiled/next-server/app-page-turbo.runtime.dev.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-unit-async-storage.external.js [external] (next/dist/server/app-render/work-unit-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-unit-async-storage.external.js", () => require("next/dist/server/app-render/work-unit-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/work-async-storage.external.js [external] (next/dist/server/app-render/work-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/work-async-storage.external.js", () => require("next/dist/server/app-render/work-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/shared/lib/no-fallback-error.external.js [external] (next/dist/shared/lib/no-fallback-error.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/shared/lib/no-fallback-error.external.js", () => require("next/dist/shared/lib/no-fallback-error.external.js"));

module.exports = mod;
}),
"[externals]/next/dist/server/app-render/after-task-async-storage.external.js [external] (next/dist/server/app-render/after-task-async-storage.external.js, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("next/dist/server/app-render/after-task-async-storage.external.js", () => require("next/dist/server/app-render/after-task-async-storage.external.js"));

module.exports = mod;
}),
"[externals]/util [external] (util, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("util", () => require("util"));

module.exports = mod;
}),
"[externals]/stream [external] (stream, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("stream", () => require("stream"));

module.exports = mod;
}),
"[externals]/path [external] (path, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("path", () => require("path"));

module.exports = mod;
}),
"[externals]/http [external] (http, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http", () => require("http"));

module.exports = mod;
}),
"[externals]/https [external] (https, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("https", () => require("https"));

module.exports = mod;
}),
"[externals]/url [external] (url, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("url", () => require("url"));

module.exports = mod;
}),
"[externals]/fs [external] (fs, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("fs", () => require("fs"));

module.exports = mod;
}),
"[externals]/crypto [external] (crypto, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("crypto", () => require("crypto"));

module.exports = mod;
}),
"[externals]/http2 [external] (http2, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("http2", () => require("http2"));

module.exports = mod;
}),
"[externals]/assert [external] (assert, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("assert", () => require("assert"));

module.exports = mod;
}),
"[externals]/tty [external] (tty, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("tty", () => require("tty"));

module.exports = mod;
}),
"[externals]/os [external] (os, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("os", () => require("os"));

module.exports = mod;
}),
"[externals]/zlib [external] (zlib, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("zlib", () => require("zlib"));

module.exports = mod;
}),
"[externals]/events [external] (events, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("events", () => require("events"));

module.exports = mod;
}),
"[project]/src/lib/lark-api.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LarkBitableAPI",
    ()=>LarkBitableAPI,
    "larkAPI",
    ()=>larkAPI
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/axios/lib/axios.js [app-route] (ecmascript)");
;
class LarkBitableAPI {
    config;
    accessToken = null;
    tokenExpireTime = 0;
    constructor(config){
        this.config = {
            baseUrl: 'https://open.feishu.cn',
            ...config
        };
    }
    /**
   * 获取访问令牌
   */ async getAccessToken() {
        // 检查token是否过期
        if (this.accessToken && Date.now() < this.tokenExpireTime) {
            return this.accessToken;
        }
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].post(`${this.config.baseUrl}/open-apis/auth/v3/tenant_access_token/internal`, {
                app_id: this.config.appId,
                app_secret: this.config.appSecret
            });
            if (response.data.code === 0) {
                this.accessToken = response.data.tenant_access_token;
                // 提前5分钟刷新token
                this.tokenExpireTime = Date.now() + (response.data.expire - 300) * 1000;
                return this.accessToken;
            } else {
                throw new Error(`获取访问令牌失败: ${response.data.msg}`);
            }
        } catch (error) {
            throw new Error(`飞书API认证失败: ${error}`);
        }
    }
    /**
   * 获取多维表格数据
   */ async getBitableRecords(appToken, tableId, pageSize = 100) {
        const accessToken = await this.getAccessToken();
        const records = [];
        let pageToken;
        do {
            try {
                const url = `${this.config.baseUrl}/open-apis/bitable/v1/apps/${appToken}/tables/${tableId}/records`;
                const params = {
                    page_size: pageSize
                };
                if (pageToken) {
                    params.page_token = pageToken;
                }
                const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].get(url, {
                    headers: {
                        'Authorization': `Bearer ${accessToken}`,
                        'Content-Type': 'application/json'
                    },
                    params
                });
                if (response.data.code === 0) {
                    const data = response.data.data;
                    if (data.items) {
                        records.push(...data.items);
                    }
                    pageToken = data.page_token;
                } else {
                    throw new Error(`获取多维表格数据失败: ${response.data.msg}`);
                }
            } catch (error) {
                console.error('获取多维表格记录失败:', error);
                throw error;
            }
        }while (pageToken)
        return records;
    }
    /**
   * 获取多维表格元数据
   */ async getBitableTables(appToken) {
        const accessToken = await this.getAccessToken();
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].get(`${this.config.baseUrl}/open-apis/bitable/v1/apps/${appToken}/tables`, {
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                }
            });
            if (response.data.code === 0) {
                return response.data.data.items || [];
            } else {
                throw new Error(`获取多维表格元数据失败: ${response.data.msg}`);
            }
        } catch (error) {
            console.error('获取多维表格元数据失败:', error);
            throw error;
        }
    }
    /**
   * 获取应用信息
   */ async getBitableApp(appToken) {
        const accessToken = await this.getAccessToken();
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].get(`${this.config.baseUrl}/open-apis/bitable/v1/apps/${appToken}`, {
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                }
            });
            if (response.data.code === 0) {
                return response.data.data.app;
            } else {
                throw new Error(`获取多维表格应用失败: ${response.data.msg}`);
            }
        } catch (error) {
            console.error('获取多维表格应用失败:', error);
            throw error;
        }
    }
    /**
   * 获取字段信息
   */ async getBitableFields(appToken, tableId) {
        const accessToken = await this.getAccessToken();
        try {
            const response = await __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$axios$2f$lib$2f$axios$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["default"].get(`${this.config.baseUrl}/open-apis/bitable/v1/apps/${appToken}/tables/${tableId}/fields`, {
                headers: {
                    'Authorization': `Bearer ${accessToken}`,
                    'Content-Type': 'application/json'
                }
            });
            if (response.data.code === 0) {
                return response.data.data.items || [];
            } else {
                throw new Error(`获取字段信息失败: ${response.data.msg}`);
            }
        } catch (error) {
            console.error('获取字段信息失败:', error);
            throw error;
        }
    }
}
const larkAPI = new LarkBitableAPI({
    appId: process.env.LARK_APP_ID || '',
    appSecret: process.env.LARK_APP_SECRET || ''
});
}),
"[project]/src/lib/data-converter.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "DataConverter",
    ()=>DataConverter
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$lark$2d$api$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/lark-api.ts [app-route] (ecmascript)");
;
class DataConverter {
    // 默认字段映射配置
    static fieldMapping = {
        '产品名称': 'name',
        '基金名称': 'name',
        '投资策略': 'strategy',
        '策略': 'strategy',
        '策略类型': 'strategy',
        '投资经理': 'manager',
        '经理': 'manager',
        '最新净值日期': 'latestNavDate',
        '净值日期': 'latestNavDate',
        '累计收益率': 'cumulativeReturn',
        '累计盈亏率': 'cumulativeReturn',
        '收益率': 'cumulativeReturn',
        // '本年收益率': 'annualizedReturn', // Moved to bottom
        '年化收益率': 'annualizedReturn',
        '最大回撤': 'maxDrawdown',
        '夏普比率': 'sharpeRatio',
        '波动率': 'volatility',
        '总规模': 'totalAssets',
        '规模': 'totalAssets',
        '总份额': 'totalAssets',
        '存续规模': 'standingAssets',
        '站岗资金': 'cashAllocation',
        '站岗资金占用': 'cashAllocation',
        '日均资金占用': 'cost',
        '状态': 'status',
        '成立日期': 'establishmentDate',
        '成本': 'cost',
        '当前规模': 'scale',
        '本周收益率': 'weeklyReturn',
        '周收益率': 'weeklyReturn',
        '本周盈亏率': 'weeklyReturn',
        '日收益率': 'dailyReturn',
        '日盈亏率': 'dailyReturn',
        '日收益': 'dailyReturn',
        '本日盈亏': 'dailyPnl',
        '当日盈亏': 'dailyPnl',
        '日收益额': 'dailyPnl',
        '持有成本': 'cost',
        '投资成本': 'cost',
        '本年收益率': 'yearlyReturn' // 修正：本年收益率对应yearlyReturn
    };
    // 策略类型选项ID的临时映射（基于已知的选项）
    static strategyOptionMapping = {
        'opteZ8clPp': '指增',
        'optAf8gJwT': '指增',
        'optBf2hKwU': 'CTA',
        'optCg3lLxV': '量选',
        'optDh4mMyW': '宏观',
        'optEi5nNzX': '套利',
        'optFj6oOaY': '债券',
        'optGk7pPbZ': '混合',
        'optHl8qQcA': '管理期货',
        'optvE8Axra': '中性',
        'optztNchXY': '可转债',
        'optA6mwCSf': '量选',
        'optN5SM1ew': 'T0',
        'optMJZQ4p5': '混合',
        'optpdOvS5N': 'CTA',
        'optcXUA9c6': '套利',
        'optHhPUvUQ': '择时对冲',
        'optC7xvukD': '期权',
        'optTiming': '择时'
    };
    /**
   * 创建选项ID到名称的映射
   */ static async createOptionMapping(appToken, tableId) {
        try {
            const api = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$lark$2d$api$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LarkBitableAPI"]({
                appId: process.env.LARK_APP_ID,
                appSecret: process.env.LARK_APP_SECRET
            });
            const fields = await api.getBitableFields(appToken, tableId);
            const optionMappings = {};
            console.log('获取到的字段数量:', fields.length);
            for (const field of fields){
                console.log(`字段: ${field.field_name}, 类型: ${field.type}, UI类型: ${field.ui_type}`);
                if (field.type === 3 || field.ui_type === 'SingleSelect' || field.ui_type === 'MultiSelect') {
                    const mapping = {};
                    console.log(`选项字段 ${field.field_name} 的选项:`, field.property?.options);
                    if (field.property && field.property.options) {
                        for (const option of field.property.options){
                            mapping[option.name] = option.name;
                            // 也为可能的选项ID创建映射
                            if (option.option_id) {
                                mapping[option.option_id] = option.name;
                                console.log(`映射: ${option.option_id} -> ${option.name}`);
                            }
                            // 也为选项的其他可能ID格式创建映射
                            if (option.id) {
                                mapping[option.id] = option.name;
                                console.log(`映射ID: ${option.id} -> ${option.name}`);
                            }
                        }
                    }
                    optionMappings[field.field_name] = mapping;
                    console.log(`字段 ${field.field_name} 的映射:`, optionMappings[field.field_name]);
                }
            // 查找字段暂时跳过，使用静态映射处理策略类型
            // TODO: 后续可以优化查找字段的动态选项获取
            }
            console.log('最终选项映射:', optionMappings);
            return optionMappings;
        } catch (error) {
            console.warn('创建选项映射失败:', error);
            return {};
        }
    }
    /**
   * 转换飞书多维表格数据为基金数据（支持选项转换）
   */ static async convertBitableToFundDataWithOptions(records, appToken, tableId, customMapping) {
        // 创建选项映射
        const optionMappings = await this.createOptionMapping(appToken, tableId);
        // 根据表格ID定义特定映射
        let tableSpecificMapping = {};
        if (tableId === 'tblXwpq4lQzfymME') {
            tableSpecificMapping = {
                '基金名称': 'name',
                '净值日期': 'latestNavDate',
                '资产净值': 'totalAssets',
                '成本': 'cost',
                '持有份额': 'scale'
            };
        } else if (tableId === 'tblcXqDbfgA0x533') {
            tableSpecificMapping = {
                '当日盈亏': 'dailyPnl',
                '本年收益率': 'yearlyReturn',
                '本周收益率': 'weeklyReturn',
                '投资成本': 'cost',
                '资产净值': 'totalAssets'
            };
        }
        const finalMapping = {
            ...customMapping,
            ...tableSpecificMapping
        };
        // 使用带有选项转换的转换方法
        const data = this.convertBitableToFundData(records, finalMapping, optionMappings);
        // 对FOF表进行特殊处理（设置默认值）
        if (tableId === 'tblXwpq4lQzfymME') {
            data.forEach((item)=>{
                if (!item.strategy) item.strategy = 'FOF';
                if (!item.manager) item.manager = '第一创业';
            });
        }
        return data;
    }
    /**
   * 转换飞书多维表格数据为基金数据
   */ static convertBitableToFundData(records, customMapping, optionMappings) {
        const mapping = {
            ...this.fieldMapping,
            ...customMapping
        };
        const convertedData = [];
        for (const record of records){
            try {
                const fundData = {
                    id: record.record_id,
                    name: this.getFieldValue(record.fields, 'name', mapping, optionMappings) || '',
                    strategy: this.getFieldValue(record.fields, 'strategy', mapping, optionMappings) || '',
                    manager: this.getFieldValue(record.fields, 'manager', mapping, optionMappings) || '',
                    latestNavDate: this.parseDate(this.getFieldValue(record.fields, 'latestNavDate', mapping, optionMappings)),
                    cumulativeReturn: this.parseNumber(this.getFieldValue(record.fields, 'cumulativeReturn', mapping, optionMappings)),
                    annualizedReturn: this.parseNumber(this.getFieldValue(record.fields, 'annualizedReturn', mapping, optionMappings)),
                    maxDrawdown: this.parseNumber(this.getFieldValue(record.fields, 'maxDrawdown', mapping, optionMappings)),
                    sharpeRatio: this.parseNumber(this.getFieldValue(record.fields, 'sharpeRatio', mapping, optionMappings)),
                    volatility: this.parseNumber(this.getFieldValue(record.fields, 'volatility', mapping, optionMappings)),
                    totalAssets: this.parseCurrency(this.getFieldValue(record.fields, 'totalAssets', mapping, optionMappings)),
                    standingAssets: this.parseCurrency(this.getFieldValue(record.fields, 'standingAssets', mapping, optionMappings)),
                    cashAllocation: this.parseCurrency(this.getFieldValue(record.fields, 'cashAllocation', mapping, optionMappings)),
                    status: this.getFieldValue(record.fields, 'status', mapping, optionMappings) || '正常'
                };
                // 可选字段
                const establishmentDate = this.getFieldValue(record.fields, 'establishmentDate', mapping, optionMappings);
                if (establishmentDate) {
                    fundData.establishmentDate = this.parseDate(establishmentDate);
                }
                const cost = this.getFieldValue(record.fields, 'cost', mapping, optionMappings);
                if (cost) {
                    fundData.cost = this.parseCurrency(cost);
                }
                const scale = this.getFieldValue(record.fields, 'scale', mapping, optionMappings);
                if (scale) {
                    fundData.scale = this.parseCurrency(scale);
                }
                const weeklyReturn = this.getFieldValue(record.fields, 'weeklyReturn', mapping, optionMappings);
                if (weeklyReturn) {
                    fundData.weeklyReturn = this.parseNumber(weeklyReturn);
                }
                const dailyReturn = this.getFieldValue(record.fields, 'dailyReturn', mapping, optionMappings);
                if (dailyReturn) {
                    fundData.dailyReturn = this.parseNumber(dailyReturn);
                }
                const dailyPnl = this.getFieldValue(record.fields, 'dailyPnl', mapping, optionMappings);
                if (dailyPnl) {
                    fundData.dailyPnl = this.parseCurrency(dailyPnl);
                }
                const yearlyReturn = this.getFieldValue(record.fields, 'yearlyReturn', mapping, optionMappings);
                if (yearlyReturn) {
                    fundData.yearlyReturn = this.parseNumber(yearlyReturn);
                }
                // 调试信息
                if (record.record_id === 'recuUuIP4mWMQn') {
                    console.log('=== 调试第一条记录转换 ===');
                    console.log('原始字段:', Object.keys(record.fields));
                    console.log('投资经理原始值:', JSON.stringify(record.fields['投资经理']));
                    console.log('本周收益率原始值:', JSON.stringify(record.fields['本周收益率']));
                    console.log('本年收益率原始值:', JSON.stringify(record.fields['本年收益率']));
                    console.log('本日盈亏原始值:', JSON.stringify(record.fields['本日盈亏']));
                    console.log('转换结果:');
                    console.log('- manager:', fundData.manager);
                    console.log('- weeklyReturn:', fundData.weeklyReturn);
                    console.log('- annualizedReturn:', fundData.annualizedReturn);
                    console.log('- dailyReturn:', fundData.dailyReturn);
                    console.log('- cost:', fundData.cost);
                }
                convertedData.push(fundData);
            } catch (error) {
                console.warn(`转换记录失败 ${record.record_id}:`, error);
            }
        }
        return convertedData;
    }
    /**
   * 转换飞书多维表格数据为基金数据（向后兼容）
   */ static convertBitableToFundDataLegacy(records, customMapping) {
        return this.convertBitableToFundData(records, customMapping);
    }
    /**
   * 获取字段值
   */ static getFieldValue(fields, targetKey, mapping, optionMappings) {
        // 查找映射的字段名
        for (const [sourceKey, mappedKey] of Object.entries(mapping)){
            if (mappedKey === targetKey && fields[sourceKey] !== undefined) {
                const value = fields[sourceKey];
                // 特殊处理策略和状态字段
                if (targetKey === 'strategy' || targetKey === 'status') {
                    const extractedValue = this.extractTextValue(value);
                    // 首先尝试使用动态选项映射
                    if (optionMappings) {
                        const fieldMapping = optionMappings[sourceKey];
                        if (fieldMapping && fieldMapping[extractedValue]) {
                            return fieldMapping[extractedValue];
                        }
                    }
                    // 对于策略字段，使用临时映射
                    if (targetKey === 'strategy' && this.strategyOptionMapping[extractedValue]) {
                        console.log(`Mapping strategy ID ${extractedValue} to ${this.strategyOptionMapping[extractedValue]}`);
                        return this.strategyOptionMapping[extractedValue];
                    }
                    return extractedValue;
                }
                // 对于投资经理字段，直接返回文本值
                if (targetKey === 'manager') {
                    return this.extractTextValue(value);
                }
                return value;
            }
        }
        return null;
    }
    /**
   * 从复杂结构中提取文本值
   */ static extractTextValue(value) {
        if (value === null || value === undefined) {
            return '未知';
        }
        if (typeof value === 'string') {
            return value;
        }
        // 处理飞书新格式: {type: 3, value: ["T0"]}
        if (typeof value === 'object' && !Array.isArray(value)) {
            // 检查是否有value属性
            if (value.value !== undefined) {
                // 递归处理value
                return this.extractTextValue(value.value);
            }
            // 如果是对象且有text属性
            if (value.text) {
                return value.text;
            }
        }
        if (Array.isArray(value)) {
            if (value.length === 0) {
                return '未知';
            }
            // 如果数组中的元素是对象且有text属性
            const firstItem = value[0];
            if (firstItem && typeof firstItem === 'object' && firstItem.text) {
                return firstItem.text;
            }
            // 如果数组中的元素是字符串
            if (typeof firstItem === 'string') {
                return firstItem;
            }
            // 默认返回对象的字符串表示
            return String(firstItem);
        }
        return String(value);
    }
    /**
   * 解析数字
   */ static parseNumber(value) {
        if (value === null || value === undefined || value === '') {
            return 0;
        }
        if (typeof value === 'number') {
            return value;
        }
        if (typeof value === 'string') {
            // 移除百分号并转换
            const cleanValue = value.toString().replace(/[%,¥]/g, '').trim();
            const parsed = parseFloat(cleanValue);
            return isNaN(parsed) ? 0 : parsed;
        }
        if (Array.isArray(value) && value.length > 0) {
            // 如果是数组，取第一个元素
            return this.parseNumber(value[0]);
        }
        return 0;
    }
    /**
   * 解析货币值
   */ static parseCurrency(value) {
        if (value === null || value === undefined || value === '') {
            return 0;
        }
        if (typeof value === 'number') {
            return value;
        }
        if (typeof value === 'string') {
            // 移除货币符号和逗号
            const cleanValue = value.toString().replace(/[¥,]/g, '').trim();
            const parsed = parseFloat(cleanValue);
            return isNaN(parsed) ? 0 : parsed;
        }
        if (Array.isArray(value) && value.length > 0) {
            // 如果是数组，取第一个元素
            return this.parseCurrency(value[0]);
        }
        return 0;
    }
    /**
   * 解析日期
   */ static parseDate(value) {
        if (value === null || value === undefined || value === '') {
            return new Date();
        }
        if (value instanceof Date) {
            return value;
        }
        if (typeof value === 'number') {
            // 可能是Excel序列日期（天数从1900-01-01开始）
            if (value > 40000 && value < 60000) {
                // 转换Excel日期为JavaScript日期
                // Excel日期从1900-01-01开始，但JavaScript从1970-01-01开始
                const excelEpoch = new Date(1900, 0, 1);
                const daysOffset = value - 2 // Excel错误地认为1900年是闰年，所以减2天
                ;
                const jsDate = new Date(excelEpoch.getTime() + daysOffset * 24 * 60 * 60 * 1000);
                return jsDate;
            }
            // 可能是时间戳
            return new Date(value);
        }
        if (typeof value === 'string') {
            // 尝试解析各种日期格式
            const dateStr = value.toString().trim();
            // ISO格式
            if (dateStr.includes('T') || dateStr.includes('-')) {
                const parsed = new Date(dateStr);
                return isNaN(parsed.getTime()) ? new Date() : parsed;
            }
            // 中文格式：2025/11/17
            if (dateStr.includes('/')) {
                const parts = dateStr.split('/');
                if (parts.length === 3) {
                    const year = parseInt(parts[0]);
                    const month = parseInt(parts[1]) - 1;
                    const day = parseInt(parts[2]);
                    const parsed = new Date(year, month, day);
                    return isNaN(parsed.getTime()) ? new Date() : parsed;
                }
            }
        }
        if (Array.isArray(value) && value.length > 0) {
            // 如果是数组，取第一个元素
            const firstItem = value[0];
            if (firstItem && typeof firstItem === 'object' && firstItem.text) {
                return this.parseDate(firstItem.text);
            }
            return this.parseDate(value[0]);
        }
        return new Date();
    }
    /**
   * 分析字段映射
   */ static analyzeFields(records) {
        if (records.length === 0) {
            return {};
        }
        const firstRecord = records[0];
        const mapping = {};
        const fields = Object.keys(firstRecord.fields);
        // 基于字段名推断映射
        for (const field of fields){
            const fieldName = field.toLowerCase();
            // 基于关键词匹配
            if (fieldName.includes('产品名称') || fieldName.includes('基金名称')) {
                mapping[field] = 'name';
            } else if (fieldName.includes('策略')) {
                mapping[field] = 'strategy';
            } else if (fieldName.includes('经理')) {
                mapping[field] = 'manager';
            } else if (fieldName.includes('净值日期') || fieldName.includes('最新净值')) {
                mapping[field] = 'latestNavDate';
            } else if (fieldName.includes('累计收益率') || fieldName.includes('累计盈亏')) {
                mapping[field] = 'cumulativeReturn';
            } else if (fieldName.includes('年化收益率') || fieldName.includes('年化')) {
                mapping[field] = 'annualizedReturn';
            } else if (fieldName.includes('最大回撤') || fieldName.includes('回撤')) {
                mapping[field] = 'maxDrawdown';
            } else if (fieldName.includes('夏普')) {
                mapping[field] = 'sharpeRatio';
            } else if (fieldName.includes('波动率') || fieldName.includes('波动')) {
                mapping[field] = 'volatility';
            } else if (fieldName.includes('总规模') || fieldName.includes('规模')) {
                mapping[field] = 'totalAssets';
            } else if (fieldName.includes('存续规模')) {
                mapping[field] = 'standingAssets';
            } else if (fieldName.includes('站岗资金')) {
                mapping[field] = 'cashAllocation';
            } else if (fieldName.includes('状态')) {
                mapping[field] = 'status';
            } else if (fieldName.includes('成立日期') || fieldName.includes('成立')) {
                mapping[field] = 'establishmentDate';
            } else if (fieldName.includes('成本')) {
                mapping[field] = 'cost';
            }
        }
        return mapping;
    }
}
}),
"[externals]/sqlite3 [external] (sqlite3, cjs)", ((__turbopack_context__, module, exports) => {

const mod = __turbopack_context__.x("sqlite3", () => require("sqlite3"));

module.exports = mod;
}),
"[project]/src/lib/database-server.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "Database",
    ()=>Database,
    "getDatabase",
    ()=>getDatabase
]);
var __TURBOPACK__imported__module__$5b$externals$5d2f$sqlite3__$5b$external$5d$__$28$sqlite3$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/sqlite3 [external] (sqlite3, cjs)");
var __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__ = __turbopack_context__.i("[externals]/path [external] (path, cjs)");
;
;
const DB_PATH = (0, __TURBOPACK__imported__module__$5b$externals$5d2f$path__$5b$external$5d$__$28$path$2c$__cjs$29$__["join"])(process.cwd(), 'data', 'funds.db');
class Database {
    db;
    constructor(){
        this.db = new __TURBOPACK__imported__module__$5b$externals$5d2f$sqlite3__$5b$external$5d$__$28$sqlite3$2c$__cjs$29$__["default"].Database(DB_PATH);
        this.initTables();
    }
    initTables() {
        // 基金基本信息表 - 更新为新的列结构
        this.db.run(`
      CREATE TABLE IF NOT EXISTS funds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        record_id TEXT UNIQUE,
        name TEXT NOT NULL,
        strategy TEXT,
        manager TEXT,
        latest_nav_date DATE,

        -- 新的收益率字段
        weekly_return REAL DEFAULT 0,
        daily_return REAL DEFAULT 0,
        daily_pnl REAL DEFAULT 0,
        yearly_return REAL DEFAULT 0,
        cumulative_return REAL DEFAULT 0,
        annualized_return REAL DEFAULT 0,

        -- 新的集中度和成本字段
        concentration REAL DEFAULT 0,
        cost REAL DEFAULT 0,
        total_assets REAL DEFAULT 0,
        standing_assets REAL DEFAULT 0,
        cash_allocation REAL DEFAULT 0,

        -- 状态字段
        status TEXT DEFAULT '正常',

        -- 需要计算的字段
        max_drawdown REAL DEFAULT 0,
        sharpe_ratio REAL DEFAULT 0,
        volatility REAL DEFAULT 0,

        -- 保留字段
        establishment_date DATE,
        scale REAL DEFAULT 0,
        source_table TEXT DEFAULT 'main',

        -- 时间戳
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
        // 基金净值历史表
        this.db.run(`
      CREATE TABLE IF NOT EXISTS fund_nav_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fund_id TEXT,
        nav_date DATE,
        unit_nav REAL,
        cumulative_nav REAL,
        daily_return REAL,
        total_assets REAL,
        status TEXT,
        record_time DATETIME,
        cost REAL,
        market_value REAL,
        position_change REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (fund_id) REFERENCES funds (id)
      )
    `);
        // 数据同步日志表
        this.db.run(`
      CREATE TABLE IF NOT EXISTS sync_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sync_type TEXT,
        status TEXT,
        records_processed INTEGER,
        records_updated INTEGER,
        error_message TEXT,
        sync_start DATETIME,
        sync_end DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `);
        // 创建索引
        this.db.run('CREATE INDEX IF NOT EXISTS idx_fund_nav_date ON fund_nav_history (fund_id, nav_date)');
        this.db.run('CREATE INDEX IF NOT EXISTS idx_fund_strategy ON funds (strategy)');
        this.db.run('CREATE INDEX IF NOT EXISTS idx_fund_manager ON funds (manager)');
    }
    // 基金相关操作
    async getAllFunds(source = 'main') {
        return new Promise((resolve, reject)=>{
            this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.source_table = ?
        ORDER BY f.yearly_return DESC
      `, [
                source
            ], (err, rows)=>{
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
    async getFundById(id) {
        return new Promise((resolve, reject)=>{
            this.db.get('SELECT * FROM funds WHERE record_id = ?', [
                id
            ], (err, row)=>{
                if (err) reject(err);
                else resolve(row);
            });
        });
    }
    async getFundsByStrategy(strategy, source = 'main') {
        return new Promise((resolve, reject)=>{
            this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.strategy = ? AND f.source_table = ?
        ORDER BY f.yearly_return DESC
      `, [
                strategy,
                source
            ], (err, rows)=>{
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
    async getFundsByManager(manager, source = 'main') {
        return new Promise((resolve, reject)=>{
            this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.manager = ? AND f.source_table = ?
        ORDER BY f.yearly_return DESC
      `, [
                manager,
                source
            ], (err, rows)=>{
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
    // 统计相关操作
    async getStrategyStats(source = 'main') {
        return new Promise((resolve, reject)=>{
            this.db.all(`
        SELECT
          strategy,
          COUNT(*) as fund_count,
          AVG(yearly_return) as avg_return,
          AVG(max_drawdown) as avg_max_drawdown,
          AVG(sharpe_ratio) as avg_sharpe_ratio,
          AVG(volatility) as avg_volatility,
          SUM(cost) as total_cost
        FROM funds
        WHERE strategy IS NOT NULL AND source_table = ?
        GROUP BY strategy
        ORDER BY avg_return DESC
      `, [
                source
            ], (err, rows)=>{
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
    async getManagerStats(source = 'main') {
        return new Promise((resolve, reject)=>{
            this.db.all(`
        SELECT
          manager,
          COUNT(*) as fund_count,
          SUM(cost) as total_cost,
          AVG(yearly_return) as avg_return,
          MAX(yearly_return) as best_return,
          (SELECT name FROM funds f2 WHERE f2.manager = f1.manager AND f2.source_table = ? ORDER BY yearly_return DESC LIMIT 1) as best_fund_name
        FROM funds f1
        WHERE manager IS NOT NULL AND source_table = ?
        GROUP BY manager
        ORDER BY avg_return DESC
      `, [
                source,
                source
            ], (err, rows)=>{
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
    async getFundHistory(fundId) {
        return new Promise((resolve, reject)=>{
            this.db.all(`
        SELECT 
          nav_date as date, 
          nav_date,
          daily_return as value, 
          daily_return,
          unit_nav, 
          cumulative_nav, 
          market_value
        FROM fund_nav_history
        WHERE fund_id = ?
        ORDER BY nav_date ASC
      `, [
                fundId
            ], (err, rows)=>{
                if (err) reject(err);
                else resolve(rows);
            });
        });
    }
    // 关闭数据库连接
    close() {
        this.db.close();
    }
}
// 创建全局数据库实例
let dbInstance;
function getDatabase() {
    if (!dbInstance) {
        dbInstance = new Database();
    }
    return dbInstance;
}
}),
"[project]/src/lib/lark-sync.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "LarkSyncService",
    ()=>LarkSyncService
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$lark$2d$api$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/lark-api.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2d$converter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/data-converter.ts [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2d$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/database-server.ts [app-route] (ecmascript)");
;
;
;
class LarkSyncService {
    api;
    constructor(appId, appSecret){
        this.api = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$lark$2d$api$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LarkBitableAPI"]({
            appId: appId || process.env.LARK_APP_ID,
            appSecret: appSecret || process.env.LARK_APP_SECRET
        });
    }
    /**
   * 从飞书多维表格同步数据
   */ async syncFromBitable(config) {
        const result = {
            success: false,
            recordsProcessed: 0,
            recordsUpdated: 0,
            recordsInserted: 0,
            errors: [],
            warnings: []
        };
        try {
            console.log('开始从飞书多维表格同步数据...');
            const tablesToSync = config.tables || [
                {
                    id: 'tblcXqDbfgA0x533',
                    type: 'main'
                },
                {
                    id: 'tblXwpq4lQzfymME',
                    type: 'fof'
                } // 第一创业FOF
            ];
            for (const table of tablesToSync){
                console.log(`正在同步表格: ${table.id} (${table.type})...`);
                try {
                    // 获取数据
                    const records = await this.api.getBitableRecords(config.appToken, table.id);
                    if (records.length === 0) {
                        result.warnings.push(`表格 ${table.id} 中没有数据`);
                        continue;
                    }
                    result.recordsProcessed += records.length;
                    // 私募取数表作为历史数据处理
                    if (table.id === 'tblcXqDbfgA0x533') {
                        console.log('同步历史净值数据...');
                        const historyResult = await this.syncNavHistory(records);
                        console.log(`历史数据同步完成: ${historyResult.inserted} 条记录`);
                        // 计算基金指标
                        console.log('计算基金指标...');
                        const metricsResult = await this.calculateFundMetrics();
                        console.log(`指标计算完成: ${metricsResult.fundsUpdated} 个基金`);
                    }
                    // 转换数据格式
                    const fieldMapping = __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2d$converter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DataConverter"].analyzeFields(records);
                    const fundData = await __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$data$2d$converter$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["DataConverter"].convertBitableToFundDataWithOptions(records, config.appToken, table.id);
                    // 添加来源标记
                    fundData.forEach((fund)=>{
                        fund.source_table = table.type;
                    });
                    // 保存到数据库
                    const dbResult = await this.saveToDatabase(fundData);
                    result.recordsUpdated += dbResult.updated;
                    result.recordsInserted += dbResult.inserted;
                } catch (tableError) {
                    console.error(`同步表格 ${table.id} 失败:`, tableError);
                    result.errors.push(`表格 ${table.id} 同步失败: ${tableError}`);
                }
            }
            result.success = result.errors.length === 0;
            console.log(`同步完成: 处理${result.recordsProcessed}条记录，更新${result.recordsUpdated}条，插入${result.recordsInserted}条`);
        } catch (error) {
            console.error('同步流程失败:', error);
            result.errors.push(`同步流程失败: ${error}`);
        }
        return result;
    }
    /**
   * 自动检测基金数据表
   */ async detectFundTable(appToken) {
        try {
            const tables = await this.api.getBitableTables(appToken);
            // 优先查找包含"基金"、"私募"等关键词的表格
            const fundTables = tables.filter((table)=>{
                const name = table.name.toLowerCase();
                return name.includes('基金') || name.includes('私募') || name.includes('投资');
            });
            if (fundTables.length > 0) {
                return fundTables[0].table_id;
            }
            // 如果没找到，返回第一个表格
            if (tables.length > 0) {
                return tables[0].table_id;
            }
            return null;
        } catch (error) {
            console.error('检测表格失败:', error);
            return null;
        }
    }
    /**
   * 保存数据到数据库
   */ async saveToDatabase(fundData) {
        const db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2d$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDatabase"])();
        let updated = 0;
        let inserted = 0;
        try {
            for (const fund of fundData){
                // 检查基金是否已存在
                const existingFund = await this.findExistingFund(db, fund.name, fund.manager);
                if (existingFund) {
                    // 更新现有记录
                    await this.updateFund(db, fund, existingFund.id);
                    updated++;
                } else {
                    // 插入新记录
                    await this.insertFund(db, fund);
                    inserted++;
                }
            }
        } catch (error) {
            console.error('保存数据失败:', error);
            throw error;
        }
        return {
            updated,
            inserted
        };
    }
    /**
   * 查找已存在的基金
   */ async findExistingFund(db, name, manager) {
        return new Promise((resolve, reject)=>{
            const dbInstance = db.db;
            dbInstance.get('SELECT id FROM funds WHERE name = ? AND (manager = ? OR manager IS NULL)', [
                name,
                manager || ''
            ], (err, row)=>{
                if (err) reject(err);
                else resolve(row);
            });
        });
    }
    /**
   * 更新基金信息
   */ async updateFund(db, fund, id) {
        return new Promise((resolve, reject)=>{
            const dbInstance = db.db;
            const stmt = dbInstance.prepare(`
        UPDATE funds SET
          name = ?, strategy = ?, manager = ?, latest_nav_date = ?,
          cumulative_return = ?, annualized_return = ?, max_drawdown = ?,
          sharpe_ratio = ?, volatility = ?, total_assets = ?,
          standing_assets = ?, cash_allocation = ?, status = ?,
          establishment_date = ?, cost = ?, scale = ?,
          weekly_return = ?, daily_return = ?, daily_pnl = ?, updated_at = CURRENT_TIMESTAMP,
          source_table = ?
        WHERE id = ?
      `);
            stmt.run([
                fund.name,
                fund.strategy,
                fund.manager,
                fund.latestNavDate?.toISOString(),
                fund.cumulativeReturn,
                fund.annualizedReturn,
                fund.maxDrawdown,
                fund.sharpeRatio,
                fund.volatility,
                fund.totalAssets,
                fund.standingAssets,
                fund.cashAllocation,
                fund.status,
                fund.establishmentDate?.toISOString(),
                fund.cost,
                fund.scale,
                fund.weeklyReturn || 0,
                fund.dailyReturn || 0,
                fund.dailyPnl || 0,
                fund.source_table,
                id
            ], (err)=>{
                if (err) reject(err);
                else resolve();
            });
            stmt.finalize();
        });
    }
    /**
   * 插入新基金
   */ async insertFund(db, fund) {
        return new Promise((resolve, reject)=>{
            const dbInstance = db.db;
            const stmt = dbInstance.prepare(`
        INSERT INTO funds (
          id, name, strategy, manager, latest_nav_date, cumulative_return,
          annualized_return, max_drawdown, sharpe_ratio, volatility,
          total_assets, standing_assets, cash_allocation, status,
          establishment_date, cost, scale, weekly_return, daily_return, daily_pnl, source_table
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);
            stmt.run([
                fund.id || this.generateId(),
                fund.name,
                fund.strategy,
                fund.manager,
                fund.latestNavDate?.toISOString(),
                fund.cumulativeReturn,
                fund.annualizedReturn,
                fund.maxDrawdown,
                fund.sharpeRatio,
                fund.volatility,
                fund.totalAssets,
                fund.standingAssets,
                fund.cashAllocation,
                fund.status,
                fund.establishmentDate?.toISOString(),
                fund.cost,
                fund.scale,
                fund.weeklyReturn || 0,
                fund.dailyReturn || 0,
                fund.dailyPnl || 0,
                fund.source_table
            ], (err)=>{
                if (err) reject(err);
                else resolve();
            });
            stmt.finalize();
        });
    }
    /**
   * 生成ID
   */ generateId() {
        return Date.now().toString(36) + Math.random().toString(36).substr(2);
    }
    /**
   * 获取应用信息
   */ async getBitableInfo(appToken) {
        try {
            const [app, tables] = await Promise.all([
                this.api.getBitableApp(appToken),
                this.api.getBitableTables(appToken)
            ]);
            return {
                app: {
                    name: app.name,
                    url: app.url,
                    avatar: app.avatar
                },
                tables: tables.map((table)=>({
                        table_id: table.table_id,
                        name: table.name,
                        revision: table.revision
                    }))
            };
        } catch (error) {
            console.error('获取多维表格信息失败:', error);
            throw error;
        }
    }
    /**
   * 同步净值历史数据
   */ async syncNavHistory(records) {
        const db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2d$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDatabase"])();
        const dbInstance = db.db;
        let inserted = 0;
        return new Promise((resolve, reject)=>{
            dbInstance.serialize(()=>{
                // 清空历史数据表
                dbInstance.run('DELETE FROM fund_nav_history', (err)=>{
                    if (err) {
                        console.error('清空历史数据失败:', err);
                        reject(err);
                        return;
                    }
                    const stmt = dbInstance.prepare(`
            INSERT INTO fund_nav_history (
              fund_id, nav_date, unit_nav, cumulative_nav, daily_return,
              total_assets, status, cost, market_value, position_change
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
          `);
                    for (const record of records){
                        try {
                            const fields = record.fields;
                            const fundName = fields['基金名称'] || '';
                            const navDate = this.parseNavDate(fields['净值日期']);
                            const virtualNav = this.parseNumber(fields['虚拟净值']);
                            const unitNav = this.parseNumber(fields['单位净值']);
                            const cumulativeNav = this.parseNumber(fields['累计净值']);
                            const dailyReturn = this.parseNumber(fields['本年收益率']) // 使用本年收益率作为日收益率
                            ;
                            const totalAssets = this.parseNumber(fields['资产净值']);
                            const status = fields['状态'] || '正常';
                            const cost = this.parseNumber(fields['投资成本']);
                            const marketValue = this.parseNumber(fields['市值']);
                            const positionChange = this.parseNumber(fields['持仓变化']);
                            if (!fundName || !navDate) continue;
                            stmt.run([
                                fundName,
                                navDate,
                                unitNav,
                                virtualNav,
                                dailyReturn,
                                totalAssets,
                                status,
                                cost,
                                marketValue,
                                positionChange
                            ], (err)=>{
                                if (err) {
                                    console.error(`插入历史数据失败 ${fundName}:`, err);
                                } else {
                                    inserted++;
                                }
                            });
                        } catch (error) {
                            console.warn(`处理历史记录失败:`, error);
                        }
                    }
                    stmt.finalize((err)=>{
                        if (err) reject(err);
                        else resolve({
                            inserted
                        });
                    });
                });
            });
        });
    }
    /**
   * 计算基金指标
   */ async calculateFundMetrics() {
        const db = (0, __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$database$2d$server$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["getDatabase"])();
        const dbInstance = db.db;
        let fundsUpdated = 0;
        return new Promise((resolve, reject)=>{
            // 获取所有基金的历史数据
            dbInstance.all(`
        SELECT DISTINCT fund_id FROM fund_nav_history
      `, async (err, funds)=>{
                if (err) {
                    reject(err);
                    return;
                }
                for (const fund of funds){
                    try {
                        const metrics = await this.calculateMetricsForFund(dbInstance, fund.fund_id);
                        await this.updateFundMetrics(dbInstance, fund.fund_id, metrics);
                        fundsUpdated++;
                    } catch (error) {
                        console.error(`计算基金 ${fund.fund_id} 指标失败:`, error);
                    }
                }
                resolve({
                    fundsUpdated
                });
            });
        });
    }
    /**
   * 计算单个基金的指标
   */ async calculateMetricsForFund(db, fundId) {
        return new Promise((resolve, reject)=>{
            db.all(`
        SELECT nav_date, cumulative_nav, daily_return
        FROM fund_nav_history
        WHERE fund_id = ? AND cumulative_nav > 0
        ORDER BY nav_date ASC
      `, [
                fundId
            ], (err, history)=>{
                if (err) {
                    reject(err);
                    return;
                }
                if (history.length < 2) {
                    resolve({
                        maxDrawdown: 0,
                        volatility: 0,
                        sharpeRatio: 0,
                        annualizedReturn: 0
                    });
                    return;
                }
                try {
                    // 计算最大回撤
                    let maxDrawdown = 0;
                    let peak = history[0].cumulative_nav;
                    for (const point of history){
                        const nav = parseFloat(point.cumulative_nav);
                        if (isNaN(nav) || nav <= 0) continue;
                        if (nav > peak) {
                            peak = nav;
                        }
                        const drawdown = (peak - nav) / peak;
                        if (drawdown > maxDrawdown) {
                            maxDrawdown = drawdown;
                        }
                    }
                    // 计算日收益率序列
                    const returns = [];
                    for(let i = 1; i < history.length; i++){
                        const prevNav = parseFloat(history[i - 1].cumulative_nav);
                        const currNav = parseFloat(history[i].cumulative_nav);
                        if (isNaN(prevNav) || isNaN(currNav) || prevNav <= 0 || currNav <= 0) continue;
                        returns.push((currNav - prevNav) / prevNav);
                    }
                    // 计算波动率（年化）
                    let volatility = 0;
                    if (returns.length > 1) {
                        const mean = returns.reduce((a, b)=>a + b, 0) / returns.length;
                        const variance = returns.reduce((sum, r)=>sum + Math.pow(r - mean, 2), 0) / returns.length;
                        volatility = Math.sqrt(variance) * Math.sqrt(252); // 年化
                    }
                    // 计算年化收益率
                    const firstNav = parseFloat(history[0].cumulative_nav);
                    const lastNav = parseFloat(history[history.length - 1].cumulative_nav);
                    const firstDate = new Date(history[0].nav_date);
                    const lastDate = new Date(history[history.length - 1].nav_date);
                    const days = (lastDate.getTime() - firstDate.getTime()) / (1000 * 60 * 60 * 24);
                    let annualizedReturn = 0;
                    if (days > 0 && firstNav > 0 && lastNav > 0) {
                        const totalReturn = lastNav / firstNav - 1;
                        annualizedReturn = Math.pow(1 + totalReturn, 365 / days) - 1;
                    }
                    // 计算夏普比率（假设无风险利率为2%）
                    const riskFreeRate = 0.02;
                    const sharpeRatio = volatility > 0 ? (annualizedReturn - riskFreeRate) / volatility : 0;
                    resolve({
                        maxDrawdown: maxDrawdown * 100,
                        volatility: volatility * 100,
                        sharpeRatio,
                        annualizedReturn: annualizedReturn * 100
                    });
                } catch (error) {
                    console.error(`计算基金 ${fundId} 指标时出错:`, error);
                    resolve({
                        maxDrawdown: 0,
                        volatility: 0,
                        sharpeRatio: 0,
                        annualizedReturn: 0
                    });
                }
            });
        });
    }
    /**
   * 更新基金指标
   */ async updateFundMetrics(db, fundId, metrics) {
        return new Promise((resolve, reject)=>{
            db.run(`
        UPDATE funds
        SET max_drawdown = ?, sharpe_ratio = ?, volatility = ?, annualized_return = ?
        WHERE name = ?
      `, [
                metrics.maxDrawdown,
                metrics.sharpeRatio,
                metrics.volatility,
                metrics.annualizedReturn,
                fundId
            ], (err)=>{
                if (err) reject(err);
                else resolve();
            });
        });
    }
    /**
   * 解析净值日期
   */ parseNavDate(value) {
        if (!value) return null;
        if (typeof value === 'number') {
            // 时间戳（毫秒）
            const date = new Date(value);
            return date.toISOString().split('T')[0];
        }
        if (typeof value === 'string') {
            return value.split('T')[0];
        }
        return null;
    }
    /**
   * 解析数字
   */ parseNumber(value) {
        if (value === null || value === undefined) return 0;
        if (typeof value === 'number') return value;
        if (typeof value === 'string') {
            const cleaned = value.replace(/[%,¥]/g, '');
            return parseFloat(cleaned) || 0;
        }
        return 0;
    }
}
}),
"[project]/src/app/api/lark-sync/route.ts [app-route] (ecmascript)", ((__turbopack_context__) => {
"use strict";

__turbopack_context__.s([
    "GET",
    ()=>GET,
    "POST",
    ()=>POST
]);
var __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/node_modules/next/server.js [app-route] (ecmascript)");
var __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$lark$2d$sync$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__ = __turbopack_context__.i("[project]/src/lib/lark-sync.ts [app-route] (ecmascript)");
;
;
async function POST(request) {
    try {
        const body = await request.json();
        const { appId, appSecret, appToken, tableId, autoDetectTable = true } = body;
        if (!appId || !appSecret) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: '缺少必需参数: appId 和 appSecret'
            }, {
                status: 400
            });
        }
        if (!appToken) {
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                error: '缺少必需参数: appToken (多维表格应用令牌)'
            }, {
                status: 400
            });
        }
        // 创建同步服务
        const syncService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$lark$2d$sync$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LarkSyncService"](appId, appSecret);
        // 执行同步
        const result = await syncService.syncFromBitable({
            appToken,
            tableId,
            autoDetectTable
        });
        // 记录同步日志到数据库
        await logSyncResult({
            syncType: 'lark_bitable',
            status: result.success ? 'success' : 'error',
            recordsProcessed: result.recordsProcessed,
            recordsUpdated: result.recordsUpdated,
            recordsInserted: result.recordsInserted,
            errorMessage: result.errors.join('; ') || null,
            appToken,
            tableId: tableId || 'auto-detected'
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            result
        });
    } catch (error) {
        console.error('飞书同步失败:', error);
        // 记录错误日志
        await logSyncResult({
            syncType: 'lark_bitable',
            status: 'error',
            recordsProcessed: 0,
            recordsUpdated: 0,
            recordsInserted: 0,
            errorMessage: error instanceof Error ? error.message : '未知错误'
        });
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: '同步失败: ' + (error instanceof Error ? error.message : '未知错误')
        }, {
            status: 500
        });
    }
}
async function GET(request) {
    const { searchParams } = new URL(request.url);
    const action = searchParams.get('action');
    try {
        if (action === 'get-table-info') {
            const appToken = searchParams.get('appToken');
            const appId = searchParams.get('appId') || process.env.LARK_APP_ID;
            const appSecret = searchParams.get('appSecret') || process.env.LARK_APP_SECRET;
            if (!appToken || !appId || !appSecret) {
                return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                    error: '缺少必需参数: appToken, appId, appSecret'
                }, {
                    status: 400
                });
            }
            const syncService = new __TURBOPACK__imported__module__$5b$project$5d2f$src$2f$lib$2f$lark$2d$sync$2e$ts__$5b$app$2d$route$5d$__$28$ecmascript$29$__["LarkSyncService"](appId, appSecret);
            const tableInfo = await syncService.getBitableInfo(appToken);
            return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
                success: true,
                data: tableInfo
            });
        }
        // 默认返回同步历史
        const db = __turbopack_context__.r("[project]/src/lib/database-server.ts [app-route] (ecmascript)").getDatabase();
        const history = await getSyncHistory();
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: true,
            data: {
                history
            }
        });
    } catch (error) {
        console.error('获取飞书信息失败:', error);
        return __TURBOPACK__imported__module__$5b$project$5d2f$node_modules$2f$next$2f$server$2e$js__$5b$app$2d$route$5d$__$28$ecmascript$29$__["NextResponse"].json({
            success: false,
            error: '操作失败: ' + (error instanceof Error ? error.message : '未知错误')
        }, {
            status: 500
        });
    }
}
// 辅助函数
async function logSyncResult(logData) {
    const sqlite3 = __turbopack_context__.r("[externals]/sqlite3 [external] (sqlite3, cjs)");
    const path = __turbopack_context__.r("[externals]/path [external] (path, cjs)");
    const DB_PATH = path.join(process.cwd(), 'data', 'funds.db');
    const db = new sqlite3.Database(DB_PATH);
    return new Promise((resolve, reject)=>{
        const stmt = db.prepare(`
      INSERT INTO sync_logs (
        sync_type, status, records_processed, records_updated,
        records_inserted, error_message, sync_start, sync_end
      ) VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `);
        const now = new Date();
        stmt.run([
            logData.syncType,
            logData.status,
            logData.recordsProcessed,
            logData.recordsUpdated,
            logData.recordsInserted,
            logData.errorMessage || null,
            now.toISOString(),
            new Date().toISOString()
        ], (err)=>{
            if (err) reject(err);
            else resolve();
        });
        stmt.finalize();
        db.close();
    });
}
async function getSyncHistory() {
    const sqlite3 = __turbopack_context__.r("[externals]/sqlite3 [external] (sqlite3, cjs)");
    const path = __turbopack_context__.r("[externals]/path [external] (path, cjs)");
    const DB_PATH = path.join(process.cwd(), 'data', 'funds.db');
    const db = new sqlite3.Database(DB_PATH);
    return new Promise((resolve, reject)=>{
        db.all(`
      SELECT * FROM sync_logs
      WHERE sync_type = 'lark_bitable'
      ORDER BY created_at DESC
      LIMIT 20
    `, (err, rows)=>{
            if (err) reject(err);
            else resolve(rows);
        });
        db.close();
    });
}
}),
];

//# sourceMappingURL=%5Broot-of-the-server%5D__7f7c5796._.js.map