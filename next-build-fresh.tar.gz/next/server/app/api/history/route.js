var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/history/route.js")
R.c("server/chunks/[root-of-the-server]__e97f12e7._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_history_route_actions_f1813cd2.js")
R.m(73642)
module.exports=R.m(73642).exports
