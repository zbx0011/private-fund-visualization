module.exports=[53595,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_fof_route_actions_2ce0af23.js.map