module.exports=[33847,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_fof_page_actions_c56463ed.js.map