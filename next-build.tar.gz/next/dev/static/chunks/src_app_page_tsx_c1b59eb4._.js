(globalThis.TURBOPACK_CHUNK_LISTS || (globalThis.TURBOPACK_CHUNK_LISTS = [])).push({
    script: typeof document === "object" ? document.currentScript : undefined,
    chunks: [
  "static/chunks/src_d14d7911._.js",
  "static/chunks/node_modules_tailwind-merge_dist_bundle-mjs_mjs_56b6fd65._.js",
  "static/chunks/node_modules_recharts_es6_util_769c20d7._.js",
  "static/chunks/node_modules_recharts_es6_state_18f28fc4._.js",
  "static/chunks/node_modules_recharts_es6_component_37778d80._.js",
  "static/chunks/node_modules_recharts_es6_cartesian_cfd2b264._.js",
  "static/chunks/node_modules_recharts_es6_a3e85291._.js",
  "static/chunks/node_modules_4d25523f._.js"
],
    source: "dynamic"
});
