module.exports=[8766,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_data_page_actions_1184ba2e.js.map