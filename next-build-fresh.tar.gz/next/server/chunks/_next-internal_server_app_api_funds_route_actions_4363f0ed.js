module.exports=[38426,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_route_actions_4363f0ed.js.map