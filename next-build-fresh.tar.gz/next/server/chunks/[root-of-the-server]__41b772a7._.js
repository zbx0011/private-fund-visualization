module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},14747,(e,t,a)=>{t.exports=e.x("path",()=>require("path"))},24361,(e,t,a)=>{t.exports=e.x("util",()=>require("util"))},88917,(e,t,a)=>{t.exports=e.x("sqlite3",()=>require("sqlite3"))},34717,e=>{"use strict";let t;var a=e.i(88917);let r=(0,e.i(14747).join)(process.cwd(),"data","funds.db");class s{db;constructor(){this.db=new a.default.Database(r),this.initTables()}initTables(){this.db.run(`
      CREATE TABLE IF NOT EXISTS funds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        record_id TEXT UNIQUE,
        name TEXT NOT NULL,
        strategy TEXT,
        manager TEXT,
        latest_nav_date DATE,

        -- 新的收益率字段
        weekly_return REAL DEFAULT 0,
        daily_return REAL DEFAULT 0,
        daily_pnl REAL DEFAULT 0,
        yearly_return REAL DEFAULT 0,
        cumulative_return REAL DEFAULT 0,
        annualized_return REAL DEFAULT 0,

        -- 新的集中度和成本字段
        concentration REAL DEFAULT 0,
        cost REAL DEFAULT 0,
        total_assets REAL DEFAULT 0,
        standing_assets REAL DEFAULT 0,
        cash_allocation REAL DEFAULT 0,

        -- 状态字段
        status TEXT DEFAULT '正常',

        -- 需要计算的字段
        max_drawdown REAL DEFAULT 0,
        sharpe_ratio REAL DEFAULT 0,
        volatility REAL DEFAULT 0,

        -- 保留字段
        establishment_date DATE,
        scale REAL DEFAULT 0,
        source_table TEXT DEFAULT 'main',

        -- 时间戳
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),this.db.run(`
      CREATE TABLE IF NOT EXISTS fund_nav_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fund_id TEXT,
        nav_date DATE,
        unit_nav REAL,
        cumulative_nav REAL,
        daily_return REAL,
        total_assets REAL,
        status TEXT,
        record_time DATETIME,
        cost REAL,
        market_value REAL,
        position_change REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (fund_id) REFERENCES funds (id)
      )
    `),this.db.run(`
      CREATE TABLE IF NOT EXISTS sync_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sync_type TEXT,
        status TEXT,
        records_processed INTEGER,
        records_updated INTEGER,
        error_message TEXT,
        sync_start DATETIME,
        sync_end DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_nav_date ON fund_nav_history (fund_id, nav_date)"),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_strategy ON funds (strategy)"),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_manager ON funds (manager)")}async getAllFunds(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async getFundById(e){return new Promise((t,a)=>{this.db.get("SELECT * FROM funds WHERE record_id = ?",[e],(e,r)=>{e?a(e):t(r)})})}async getFundsByStrategy(e,t="main"){return new Promise((a,r)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.strategy = ? AND f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e,t],(e,t)=>{e?r(e):a(t)})})}async getFundsByManager(e,t="main"){return new Promise((a,r)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.manager = ? AND f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e,t],(e,t)=>{e?r(e):a(t)})})}async getStrategyStats(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT
          strategy,
          COUNT(*) as fund_count,
          AVG(yearly_return) as avg_return,
          AVG(max_drawdown) as avg_max_drawdown,
          AVG(sharpe_ratio) as avg_sharpe_ratio,
          AVG(volatility) as avg_volatility,
          SUM(cost) as total_cost
        FROM funds
        WHERE strategy IS NOT NULL AND source_table = ?
        GROUP BY strategy
        ORDER BY avg_return DESC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async getManagerStats(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT
          manager,
          COUNT(*) as fund_count,
          SUM(cost) as total_cost,
          AVG(yearly_return) as avg_return,
          MAX(yearly_return) as best_return,
          (SELECT name FROM funds f2 WHERE f2.manager = f1.manager AND f2.source_table = ? ORDER BY yearly_return DESC LIMIT 1) as best_fund_name
        FROM funds f1
        WHERE manager IS NOT NULL AND source_table = ?
        GROUP BY manager
        ORDER BY avg_return DESC
      `,[e,e],(e,r)=>{e?a(e):t(r)})})}async getFundHistory(e){return new Promise((t,a)=>{this.db.all(`
        SELECT 
          nav_date as date, 
          nav_date,
          daily_return as value, 
          daily_return,
          unit_nav, 
          cumulative_nav, 
          market_value
        FROM fund_nav_history
        WHERE fund_id = ?
        ORDER BY nav_date ASC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async insertFund(e){return new Promise((t,a)=>{let r=this.db.prepare(`
        INSERT INTO funds (
          record_id, name, strategy, manager, latest_nav_date, 
          cumulative_return, annualized_return, max_drawdown, sharpe_ratio, volatility,
          total_assets, standing_assets, cash_allocation, status,
          establishment_date, cost, scale
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);r.run([e.id,e.name,e.strategy,e.manager,e.latestNavDate,e.cumulativeReturn,e.annualizedReturn,e.maxDrawdown,e.sharpeRatio,e.volatility,e.totalAssets,e.standingAssets,e.cashAllocation,e.status,e.establishmentDate,e.cost,e.scale],e=>{e?a(e):t()}),r.finalize()})}async insertNavHistory(e){return new Promise((t,a)=>{let r=this.db.prepare(`
        INSERT INTO fund_nav_history (
          fund_id, nav_date, unit_nav, cumulative_nav, daily_return,
          total_assets, status, record_time, cost, market_value, position_change
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);r.run([e.fundId,e.navDate,e.unitNav,e.cumulativeNav,e.dailyReturn,e.totalAssets,e.status,e.recordTime,e.cost,e.marketValue,e.positionChange],e=>{e?a(e):t()}),r.finalize()})}close(){this.db.close()}}function n(){return t||(t=new s),t}e.s(["Database",()=>s,"getDatabase",()=>n])}];

//# sourceMappingURL=%5Broot-of-the-server%5D__41b772a7._.js.map