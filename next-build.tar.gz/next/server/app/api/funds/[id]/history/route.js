var R=require("../../../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/[id]/history/route.js")
R.c("server/chunks/[root-of-the-server]__c47fd6e4._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_[id]_history_route_actions_1f715d25.js")
R.m(2490)
module.exports=R.m(2490).exports
