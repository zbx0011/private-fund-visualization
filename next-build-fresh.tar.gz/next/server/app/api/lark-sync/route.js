var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/lark-sync/route.js")
R.c("server/chunks/[root-of-the-server]__41b772a7._.js")
R.c("server/chunks/[root-of-the-server]__999399b5._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_lark-sync_route_actions_85d0b02d.js")
R.m(2625)
module.exports=R.m(2625).exports
