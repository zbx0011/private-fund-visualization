var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/fof/route.js")
R.c("server/chunks/[root-of-the-server]__ec90e1ae._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_fof_route_actions_2ce0af23.js")
R.m(78397)
module.exports=R.m(78397).exports
