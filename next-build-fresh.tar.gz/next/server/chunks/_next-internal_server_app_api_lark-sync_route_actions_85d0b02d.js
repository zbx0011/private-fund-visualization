module.exports=[24468,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_lark-sync_route_actions_85d0b02d.js.map