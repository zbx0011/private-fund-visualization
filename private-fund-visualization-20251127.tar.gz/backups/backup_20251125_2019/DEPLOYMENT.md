# 私募基金数据可视化系统 - 部署文档

## 📋 项目概述

这是一个基于 Next.js 的私募基金数据管理和可视化系统，包含：
- 📊 基金数据管理和可视化
- 🔍 外部信息监控（爬虫）
- 🚀 自动化数据同步到VPS

## 🔧 技术栈

- **前端框架**: Next.js 15 + React 19
- **数据库**: SQLite (better-sqlite3)
- **爬虫**: Puppeteer
- **样式**: Tailwind CSS
- **图表**: Recharts

---

## 📦 快速开始

### 1. 克隆项目

```bash
git clone https://github.com/zbx0011/private-fund-visualization.git
cd private-fund-visualization
```

### 2. 安装依赖

```bash
npm install
```

### 3. 启动开发服务器

```bash
npm run dev
```

访问：http://localhost:3000

---

## 🌐 页面导航

| 路径 | 说明 |
|------|------|
| `/` | 总览仪表板 |
| `/charts` | 数据图表 |
| `/manager` | 产品数据管理 |
| `/monitor` | 外部信息监控 |

---

## 🕷️ 爬虫使用

### 方法一：一键爬虫（推荐）

**双击运行：** `scrape.bat`

该脚本会自动：
1. 关闭所有Edge进程
2. 启动爬虫
3. 保存数据到数据库

### 方法二：命令行

```bash
# 确保关闭所有Edge窗口
npm run scrape:edge -- "https://www.qyyjt.cn/combination/20250603164207"
```

### ⚠️ 重要提示

- **必须先关闭所有Edge浏览器窗口**，否则会报错
- 爬虫使用你的Edge个人配置，保留登录状态
- 数据会自动去重和清洗

### 配置Edge路径

如果你的Edge安装在非默认位置，编辑 `scripts/scrape-with-edge-profile.js`:

```javascript
const EDGE_PATH = "你的Edge路径/msedge.exe";
const USER_DATA_DIR = "你的Edge用户数据路径";
```

常见路径：
- **Windows 默认**: `C:\Program Files (x86)\Microsoft\Edge\Application\msedge.exe`
- **用户数据**: `C:\Users\[用户名]\AppData\Local\Microsoft\Edge\User Data`

---

## 🔄 VPS同步

### 同步数据库到VPS

**方法一：仅同步数据库**

双击运行：`sync-db-to-vps.bat`

**方法二：同步代码+数据库**

双击运行：`sync-all.bat`

### VPS配置信息

- **服务器**: 172.245.53.67
- **用户**: root
- **密码**: Y6t1A5kp7f0PK3moOR
- **项目路径**: `/var/www/private-fund-visualization`
- **访问地址**: http://172.245.53.67:3000

### 手动同步（命令行）

```bash
# 1. 上传数据库
scp data/funds.db root@172.245.53.67:/var/www/private-fund-visualization/data/

# 2. 更新代码
git push origin main
ssh root@172.245.53.67 "cd /var/www/private-fund-visualization && git pull"
```

---

## 📁 项目结构

```
private-fund-visualization/
├── data/                       # 数据库文件（不上传到Git）
│   └── funds.db               # SQLite数据库
├── scripts/                   # 工具脚本
│   ├── scrape-with-edge-profile.js  # Edge爬虫
│   ├── clean-monitor-data.js        # 数据清洗
│   ├── clear-monitor-data.js        # 清空数据
│   └── restore-monitor-data.js      # 恢复数据
├── src/
│   ├── app/                   # Next.js页面
│   ├── components/            # React组件
│   └── lib/                   # 工具函数
├── scrape.bat                 # 一键爬虫
├── sync-db-to-vps.bat        # 同步数据库到VPS
└── sync-all.bat              # 完整同步
```

---

## 🗃️ 数据库管理

### 清空外部监控数据

```bash
node scripts/clear-monitor-data.js
```

这会：
1. 备份现有数据到 `data/monitor_backup.json`
2. 清空 `external_monitor` 表
3. 重置自增ID

### 恢复备份数据

```bash
node scripts/restore-monitor-data.js
```

### 清理脏数据

```bash
node scripts/clean-monitor-data.js
```

移除数据中的：
- "仅看此类型屏蔽此类型" 后缀
- "新闻 |" 前缀

---

## 🛠️ 开发命令

| 命令 | 说明 |
|------|------|
| `npm run dev` | 启动开发服务器 |
| `npm run build` | 构建生产版本 |
| `npm start` | 运行生产服务器 |
| `npm run scrape:edge -- <URL>` | 运行Edge爬虫 |

---

## 🚨 常见问题

### 1. 爬虫报错：浏览器已运行

**原因**: Edge进程未完全关闭

**解决**:
```bash
taskkill /F /IM msedge.exe /T
```

### 2. VPS数据不同步

**检查步骤**:
1. 确认数据库已上传: `sync-db-to-vps.bat`
2. 等待30-60秒让Next.js重新加载
3. 刷新VPS页面
4. 如仍未更新，SSH进VPS手动重启服务

### 3. 本地和VPS数据不一致

**手动对齐**:
```bash
# 上传最新数据库
scp data/funds.db root@172.245.53.67:/var/www/private-fund-visualization/data/
```

### 4. 新电脑上运行

**步骤**:
1. 克隆代码（见"快速开始"）
2. 修改Edge路径（如果不是默认）
3. 运行爬虫获取数据，或从旧电脑复制 `data/funds.db`

---

## 🔐 安全注意事项

⚠️ **重要**: 本文档包含VPS密码，请勿将此文件上传到公开仓库！

已在 `.gitignore` 中排除：
- `data/` - 数据库文件
- `user_data/` - Edge用户数据
- `*.db` - 所有SQLite数据库

---

## 📞 技术支持

如遇问题，请检查：
1. Node.js版本 >= 18
2. npm依赖是否完整安装
3. Edge浏览器是否已安装
4. 网络连接是否正常

---

## 📝 更新日志

### 2025-11-25
- ✅ 添加Edge个人配置爬虫
- ✅ 实现智能去重（跨标签页）
- ✅ 自动数据清洗
- ✅ VPS数据库同步脚本
- ✅ 完整部署文档
