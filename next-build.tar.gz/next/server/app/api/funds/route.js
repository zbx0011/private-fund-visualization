var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/funds/route.js")
R.c("server/chunks/[root-of-the-server]__abd139f2._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_funds_route_actions_4363f0ed.js")
R.m(21001)
module.exports=R.m(21001).exports
