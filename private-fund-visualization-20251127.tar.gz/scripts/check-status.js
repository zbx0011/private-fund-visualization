
const sqlite3 = require('sqlite3').verbose();
const path = require('path');

const dbPath = path.join(__dirname, '../data/funds.db');
const db = new sqlite3.Database(dbPath);

db.all("SELECT status, COUNT(*) as count FROM funds GROUP BY status", (err, rows) => {
    if (err) {
        console.error(err);
        return;
    }
    console.log('Status distribution in funds table:');
    console.table(rows);
});
