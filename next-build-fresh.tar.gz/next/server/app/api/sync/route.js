var R=require("../../../chunks/[turbopack]_runtime.js")("server/app/api/sync/route.js")
R.c("server/chunks/[root-of-the-server]__b8500329._.js")
R.c("server/chunks/[root-of-the-server]__b2da729a._.js")
R.c("server/chunks/_next-internal_server_app_api_sync_route_actions_78e25bf5.js")
R.m(48455)
module.exports=R.m(48455).exports
