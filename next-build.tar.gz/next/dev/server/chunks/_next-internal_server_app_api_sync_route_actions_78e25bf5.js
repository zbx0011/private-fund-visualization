module.exports = [
"[project]/.next-internal/server/app/api/sync/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_sync_route_actions_78e25bf5.js.map