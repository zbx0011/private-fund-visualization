module.exports=[6813,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_manager_page_actions_4a3ab43f.js.map