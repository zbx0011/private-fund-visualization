module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},14747,(e,t,a)=>{t.exports=e.x("path",()=>require("path"))},88917,(e,t,a)=>{t.exports=e.x("sqlite3",()=>require("sqlite3"))},34717,e=>{"use strict";let t;var a=e.i(88917);let r=(0,e.i(14747).join)(process.cwd(),"data","funds.db");class n{db;constructor(){this.db=new a.default.Database(r),this.initTables()}initTables(){this.db.run(`
      CREATE TABLE IF NOT EXISTS funds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        record_id TEXT UNIQUE,
        name TEXT NOT NULL,
        strategy TEXT,
        manager TEXT,
        latest_nav_date DATE,

        -- 新的收益率字段
        weekly_return REAL DEFAULT 0,
        daily_return REAL DEFAULT 0,
        daily_pnl REAL DEFAULT 0,
        yearly_return REAL DEFAULT 0,
        cumulative_return REAL DEFAULT 0,
        annualized_return REAL DEFAULT 0,

        -- 新的集中度和成本字段
        concentration REAL DEFAULT 0,
        cost REAL DEFAULT 0,
        total_assets REAL DEFAULT 0,
        standing_assets REAL DEFAULT 0,
        cash_allocation REAL DEFAULT 0,

        -- 状态字段
        status TEXT DEFAULT '正常',

        -- 需要计算的字段
        max_drawdown REAL DEFAULT 0,
        sharpe_ratio REAL DEFAULT 0,
        volatility REAL DEFAULT 0,

        -- 保留字段
        establishment_date DATE,
        scale REAL DEFAULT 0,
        source_table TEXT DEFAULT 'main',

        -- 时间戳
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),this.db.run(`
      CREATE TABLE IF NOT EXISTS fund_nav_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fund_id TEXT,
        nav_date DATE,
        unit_nav REAL,
        cumulative_nav REAL,
        daily_return REAL,
        total_assets REAL,
        status TEXT,
        record_time DATETIME,
        cost REAL,
        market_value REAL,
        position_change REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (fund_id) REFERENCES funds (id)
      )
    `),this.db.run(`
      CREATE TABLE IF NOT EXISTS sync_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sync_type TEXT,
        status TEXT,
        records_processed INTEGER,
        records_updated INTEGER,
        error_message TEXT,
        sync_start DATETIME,
        sync_end DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_nav_date ON fund_nav_history (fund_id, nav_date)"),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_strategy ON funds (strategy)"),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_manager ON funds (manager)")}async getAllFunds(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async getFundById(e){return new Promise((t,a)=>{this.db.get("SELECT * FROM funds WHERE record_id = ?",[e],(e,r)=>{e?a(e):t(r)})})}async getFundsByStrategy(e,t="main"){return new Promise((a,r)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.strategy = ? AND f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e,t],(e,t)=>{e?r(e):a(t)})})}async getFundsByManager(e,t="main"){return new Promise((a,r)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.manager = ? AND f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e,t],(e,t)=>{e?r(e):a(t)})})}async getStrategyStats(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT
          strategy,
          COUNT(*) as fund_count,
          AVG(yearly_return) as avg_return,
          AVG(max_drawdown) as avg_max_drawdown,
          AVG(sharpe_ratio) as avg_sharpe_ratio,
          AVG(volatility) as avg_volatility,
          SUM(cost) as total_cost
        FROM funds
        WHERE strategy IS NOT NULL AND source_table = ?
        GROUP BY strategy
        ORDER BY avg_return DESC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async getManagerStats(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT
          manager,
          COUNT(*) as fund_count,
          SUM(cost) as total_cost,
          AVG(yearly_return) as avg_return,
          MAX(yearly_return) as best_return,
          (SELECT name FROM funds f2 WHERE f2.manager = f1.manager AND f2.source_table = ? ORDER BY yearly_return DESC LIMIT 1) as best_fund_name
        FROM funds f1
        WHERE manager IS NOT NULL AND source_table = ?
        GROUP BY manager
        ORDER BY avg_return DESC
      `,[e,e],(e,r)=>{e?a(e):t(r)})})}async getFundHistory(e){return new Promise((t,a)=>{this.db.all(`
        SELECT 
          nav_date as date, 
          nav_date,
          daily_return as value, 
          daily_return,
          unit_nav, 
          cumulative_nav, 
          market_value
        FROM fund_nav_history
        WHERE fund_id = ?
        ORDER BY nav_date ASC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async insertFund(e){return new Promise((t,a)=>{let r=this.db.prepare(`
        INSERT INTO funds (
          record_id, name, strategy, manager, latest_nav_date, 
          cumulative_return, annualized_return, max_drawdown, sharpe_ratio, volatility,
          total_assets, standing_assets, cash_allocation, status,
          establishment_date, cost, scale
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);r.run([e.id,e.name,e.strategy,e.manager,e.latestNavDate,e.cumulativeReturn,e.annualizedReturn,e.maxDrawdown,e.sharpeRatio,e.volatility,e.totalAssets,e.standingAssets,e.cashAllocation,e.status,e.establishmentDate,e.cost,e.scale],e=>{e?a(e):t()}),r.finalize()})}async insertNavHistory(e){return new Promise((t,a)=>{let r=this.db.prepare(`
        INSERT INTO fund_nav_history (
          fund_id, nav_date, unit_nav, cumulative_nav, daily_return,
          total_assets, status, record_time, cost, market_value, position_change
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);r.run([e.fundId,e.navDate,e.unitNav,e.cumulativeNav,e.dailyReturn,e.totalAssets,e.status,e.recordTime,e.cost,e.marketValue,e.positionChange],e=>{e?a(e):t()}),r.finalize()})}close(){this.db.close()}}function s(){return t||(t=new n),t}e.s(["Database",()=>n,"getDatabase",()=>s])},73642,e=>{"use strict";var t=e.i(47909),a=e.i(74017),r=e.i(96250),n=e.i(59756),s=e.i(61916),i=e.i(14444),o=e.i(37092),d=e.i(69741),u=e.i(16795),l=e.i(87718),E=e.i(95169),c=e.i(47587),_=e.i(66012),p=e.i(70101),R=e.i(26937),T=e.i(10372),h=e.i(93695);e.i(52474);var A=e.i(220),y=e.i(89171),v=e.i(34717);async function f(e){try{let{searchParams:t}=new URL(e.url),a=t.get("fund_id");if(!a)return y.NextResponse.json({success:!1,error:"Fund ID is required"},{status:400});let r=(0,v.getDatabase)(),n=await r.getFundHistory(a);return y.NextResponse.json({success:!0,data:n})}catch(e){return console.error("History API Error:",e),y.NextResponse.json({success:!1,error:"Internal Server Error"},{status:500})}}e.s(["GET",()=>f],6878);var g=e.i(6878);let m=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/history/route",pathname:"/api/history",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/history/route.ts",nextConfigOutput:"",userland:g}),{workAsyncStorage:N,workUnitAsyncStorage:x,serverHooks:D}=m;function L(){return(0,r.patchFetch)({workAsyncStorage:N,workUnitAsyncStorage:x})}async function I(e,t,r){m.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let y="/api/history/route";y=y.replace(/\/index$/,"")||"/";let v=await m.prepare(e,t,{srcPage:y,multiZoneDraftMode:!1});if(!v)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:f,params:g,nextConfig:N,parsedUrl:x,isDraftMode:D,prerenderManifest:L,routerServerContext:I,isOnDemandRevalidate:C,revalidateOnlyGenerated:w,resolvedPathname:S,clientReferenceManifest:b,serverActionsManifest:O}=v,U=(0,d.normalizeAppPath)(y),F=!!(L.dynamicRoutes[U]||L.routes[S]),M=async()=>((null==I?void 0:I.render404)?await I.render404(e,t,x,!1):t.end("This page could not be found"),null);if(F&&!D){let e=!!L.routes[S],t=L.dynamicRoutes[U];if(t&&!1===t.fallback&&!e){if(N.experimental.adapterPath)return await M();throw new h.NoFallbackError}}let P=null;!F||m.isDev||D||(P="/index"===(P=S)?"/":P);let H=!0===m.isDev||!F,k=F&&!H;O&&b&&(0,i.setReferenceManifestsSingleton)({page:y,clientReferenceManifest:b,serverActionsManifest:O,serverModuleMap:(0,o.createServerModuleMap)({serverActionsManifest:O})});let q=e.method||"GET",X=(0,s.getTracer)(),j=X.getActiveScopeSpan(),B={params:g,prerenderManifest:L,renderOpts:{experimental:{authInterrupts:!!N.experimental.authInterrupts},cacheComponents:!!N.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:N.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r)=>m.onRequestError(e,t,r,I)},sharedContext:{buildId:f}},G=new u.NodeNextRequest(e),Y=new u.NodeNextResponse(t),K=l.NextRequestAdapter.fromNodeNextRequest(G,(0,l.signalFromNodeResponse)(t));try{let i=async e=>m.handle(K,B).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=X.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==E.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${q} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t)}else e.updateName(`${q} ${y}`)}),o=!!(0,n.getRequestMeta)(e,"minimalMode"),d=async n=>{var s,d;let u=async({previousCacheEntry:a})=>{try{if(!o&&C&&w&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await i(n);e.fetchMetrics=B.renderOpts.fetchMetrics;let d=B.renderOpts.pendingWaitUntil;d&&r.waitUntil&&(r.waitUntil(d),d=void 0);let u=B.renderOpts.collectedTags;if(!F)return await (0,_.sendResponse)(G,Y,s,B.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,p.toNodeOutgoingHttpHeaders)(s.headers);u&&(t[T.NEXT_CACHE_TAGS_HEADER]=u),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==B.renderOpts.collectedRevalidate&&!(B.renderOpts.collectedRevalidate>=T.INFINITE_CACHE)&&B.renderOpts.collectedRevalidate,r=void 0===B.renderOpts.collectedExpire||B.renderOpts.collectedExpire>=T.INFINITE_CACHE?void 0:B.renderOpts.collectedExpire;return{value:{kind:A.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await m.onRequestError(e,t,{routerKind:"App Router",routePath:y,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:C})},I),t}},l=await m.handleResponse({req:e,nextConfig:N,cacheKey:P,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:L,isRoutePPREnabled:!1,isOnDemandRevalidate:C,revalidateOnlyGenerated:w,responseGenerator:u,waitUntil:r.waitUntil,isMinimalMode:o});if(!F)return null;if((null==l||null==(s=l.value)?void 0:s.kind)!==A.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==l||null==(d=l.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});o||t.setHeader("x-nextjs-cache",C?"REVALIDATED":l.isMiss?"MISS":l.isStale?"STALE":"HIT"),D&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let E=(0,p.fromNodeOutgoingHttpHeaders)(l.value.headers);return o&&F||E.delete(T.NEXT_CACHE_TAGS_HEADER),!l.cacheControl||t.getHeader("Cache-Control")||E.get("Cache-Control")||E.set("Cache-Control",(0,R.getCacheControlHeader)(l.cacheControl)),await (0,_.sendResponse)(G,Y,new Response(l.value.body,{headers:E,status:l.value.status||200})),null};j?await d(j):await X.withPropagatedContext(e.headers,()=>X.trace(E.BaseServerSpan.handleRequest,{spanName:`${q} ${y}`,kind:s.SpanKind.SERVER,attributes:{"http.method":q,"http.target":e.url}},d))}catch(t){if(t instanceof h.NoFallbackError||await m.onRequestError(e,t,{routerKind:"App Router",routePath:U,routeType:"route",revalidateReason:(0,c.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:C})}),F)throw t;return await (0,_.sendResponse)(G,Y,new Response(null,{status:500})),null}}e.s(["handler",()=>I,"patchFetch",()=>L,"routeModule",()=>m,"serverHooks",()=>D,"workAsyncStorage",()=>N,"workUnitAsyncStorage",()=>x],73642)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__e97f12e7._.js.map