module.exports=[93695,(e,t,a)=>{t.exports=e.x("next/dist/shared/lib/no-fallback-error.external.js",()=>require("next/dist/shared/lib/no-fallback-error.external.js"))},70406,(e,t,a)=>{t.exports=e.x("next/dist/compiled/@opentelemetry/api",()=>require("next/dist/compiled/@opentelemetry/api"))},18622,(e,t,a)=>{t.exports=e.x("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js",()=>require("next/dist/compiled/next-server/app-page-turbo.runtime.prod.js"))},56704,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-async-storage.external.js",()=>require("next/dist/server/app-render/work-async-storage.external.js"))},32319,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/work-unit-async-storage.external.js",()=>require("next/dist/server/app-render/work-unit-async-storage.external.js"))},24725,(e,t,a)=>{t.exports=e.x("next/dist/server/app-render/after-task-async-storage.external.js",()=>require("next/dist/server/app-render/after-task-async-storage.external.js"))},14747,(e,t,a)=>{t.exports=e.x("path",()=>require("path"))},88917,(e,t,a)=>{t.exports=e.x("sqlite3",()=>require("sqlite3"))},34717,e=>{"use strict";let t;var a=e.i(88917);let r=(0,e.i(14747).join)(process.cwd(),"data","funds.db");class n{db;constructor(){this.db=new a.default.Database(r),this.initTables()}initTables(){this.db.run(`
      CREATE TABLE IF NOT EXISTS funds (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        record_id TEXT UNIQUE,
        name TEXT NOT NULL,
        strategy TEXT,
        manager TEXT,
        latest_nav_date DATE,

        -- 新的收益率字段
        weekly_return REAL DEFAULT 0,
        daily_return REAL DEFAULT 0,
        daily_pnl REAL DEFAULT 0,
        yearly_return REAL DEFAULT 0,
        cumulative_return REAL DEFAULT 0,
        annualized_return REAL DEFAULT 0,

        -- 新的集中度和成本字段
        concentration REAL DEFAULT 0,
        cost REAL DEFAULT 0,
        total_assets REAL DEFAULT 0,
        standing_assets REAL DEFAULT 0,
        cash_allocation REAL DEFAULT 0,

        -- 状态字段
        status TEXT DEFAULT '正常',

        -- 需要计算的字段
        max_drawdown REAL DEFAULT 0,
        sharpe_ratio REAL DEFAULT 0,
        volatility REAL DEFAULT 0,

        -- 保留字段
        establishment_date DATE,
        scale REAL DEFAULT 0,
        source_table TEXT DEFAULT 'main',

        -- 时间戳
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),this.db.run(`
      CREATE TABLE IF NOT EXISTS fund_nav_history (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        fund_id TEXT,
        nav_date DATE,
        unit_nav REAL,
        cumulative_nav REAL,
        daily_return REAL,
        total_assets REAL,
        status TEXT,
        record_time DATETIME,
        cost REAL,
        market_value REAL,
        position_change REAL,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (fund_id) REFERENCES funds (id)
      )
    `),this.db.run(`
      CREATE TABLE IF NOT EXISTS sync_logs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        sync_type TEXT,
        status TEXT,
        records_processed INTEGER,
        records_updated INTEGER,
        error_message TEXT,
        sync_start DATETIME,
        sync_end DATETIME,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      )
    `),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_nav_date ON fund_nav_history (fund_id, nav_date)"),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_strategy ON funds (strategy)"),this.db.run("CREATE INDEX IF NOT EXISTS idx_fund_manager ON funds (manager)")}async getAllFunds(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async getFundById(e){return new Promise((t,a)=>{this.db.get("SELECT * FROM funds WHERE record_id = ?",[e],(e,r)=>{e?a(e):t(r)})})}async getFundsByStrategy(e,t="main"){return new Promise((a,r)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.strategy = ? AND f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e,t],(e,t)=>{e?r(e):a(t)})})}async getFundsByManager(e,t="main"){return new Promise((a,r)=>{this.db.all(`
        SELECT f.*, h.daily_return as history_daily_return
        FROM funds f
        LEFT JOIN fund_nav_history h ON f.record_id = h.fund_id AND f.latest_nav_date = h.nav_date
        WHERE f.manager = ? AND f.source_table = ?
        ORDER BY f.yearly_return DESC
      `,[e,t],(e,t)=>{e?r(e):a(t)})})}async getStrategyStats(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT
          strategy,
          COUNT(*) as fund_count,
          AVG(yearly_return) as avg_return,
          AVG(max_drawdown) as avg_max_drawdown,
          AVG(sharpe_ratio) as avg_sharpe_ratio,
          AVG(volatility) as avg_volatility,
          SUM(cost) as total_cost
        FROM funds
        WHERE strategy IS NOT NULL AND source_table = ?
        GROUP BY strategy
        ORDER BY avg_return DESC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async getManagerStats(e="main"){return new Promise((t,a)=>{this.db.all(`
        SELECT
          manager,
          COUNT(*) as fund_count,
          SUM(cost) as total_cost,
          AVG(yearly_return) as avg_return,
          MAX(yearly_return) as best_return,
          (SELECT name FROM funds f2 WHERE f2.manager = f1.manager AND f2.source_table = ? ORDER BY yearly_return DESC LIMIT 1) as best_fund_name
        FROM funds f1
        WHERE manager IS NOT NULL AND source_table = ?
        GROUP BY manager
        ORDER BY avg_return DESC
      `,[e,e],(e,r)=>{e?a(e):t(r)})})}async getFundHistory(e){return new Promise((t,a)=>{this.db.all(`
        SELECT 
          nav_date as date, 
          nav_date,
          daily_return as value, 
          daily_return,
          unit_nav, 
          cumulative_nav, 
          market_value
        FROM fund_nav_history
        WHERE fund_id = ?
        ORDER BY nav_date ASC
      `,[e],(e,r)=>{e?a(e):t(r)})})}async insertFund(e){return new Promise((t,a)=>{let r=this.db.prepare(`
        INSERT INTO funds (
          record_id, name, strategy, manager, latest_nav_date, 
          cumulative_return, annualized_return, max_drawdown, sharpe_ratio, volatility,
          total_assets, standing_assets, cash_allocation, status,
          establishment_date, cost, scale
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);r.run([e.id,e.name,e.strategy,e.manager,e.latestNavDate,e.cumulativeReturn,e.annualizedReturn,e.maxDrawdown,e.sharpeRatio,e.volatility,e.totalAssets,e.standingAssets,e.cashAllocation,e.status,e.establishmentDate,e.cost,e.scale],e=>{e?a(e):t()}),r.finalize()})}async insertNavHistory(e){return new Promise((t,a)=>{let r=this.db.prepare(`
        INSERT INTO fund_nav_history (
          fund_id, nav_date, unit_nav, cumulative_nav, daily_return,
          total_assets, status, record_time, cost, market_value, position_change
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
      `);r.run([e.fundId,e.navDate,e.unitNav,e.cumulativeNav,e.dailyReturn,e.totalAssets,e.status,e.recordTime,e.cost,e.marketValue,e.positionChange],e=>{e?a(e):t()}),r.finalize()})}close(){this.db.close()}}function s(){return t||(t=new n),t}e.s(["Database",()=>n,"getDatabase",()=>s])},48455,e=>{"use strict";var t=e.i(47909),a=e.i(74017),r=e.i(96250),n=e.i(59756),s=e.i(61916),i=e.i(14444),o=e.i(37092),d=e.i(69741),l=e.i(16795),u=e.i(87718),c=e.i(95169),E=e.i(47587),p=e.i(66012),_=e.i(70101),T=e.i(26937),R=e.i(10372),y=e.i(93695);e.i(52474);var h=e.i(220),f=e.i(89171),A=e.i(34717);async function g(e){try{let{filePath:t}=await e.json();if(!t)return f.NextResponse.json({error:"请提供Excel文件路径"},{status:400});let a=(0,A.getDatabase)(),r=new Date,n=await D(t),s=0,i=0;if(n.sheets.includes("私募基金盈利一览表")){for(let e of n.getSheet("私募基金盈利一览表").data)if(e["产品名称"]){let t={id:e["唯一标识"]||m(),name:e["产品名称"],strategy:e["投资策略"],manager:e["投资经理"],latestNavDate:e["最新净值日期"],cumulativeReturn:parseFloat(e["累计盈亏率"])||0,annualizedReturn:parseFloat(e["年化收益率"])||0,maxDrawdown:parseFloat(e["最大回撤"])||0,sharpeRatio:parseFloat(e["夏普比率"])||0,volatility:parseFloat(e["波动率"])||0,totalAssets:N(e["总规模"]),standingAssets:N(e["总规模"]),cashAllocation:N(e["站岗资金占用"]),status:e["状态"]||"正常",establishmentDate:e["成立日期"],cost:N(e["成本"]),scale:N(e["规模"])};await a.insertFund(t),s++,i++}}if(n.sheets.includes("私募基金取数")){for(let e of n.getSheet("私募基金取数").data)if(e["产品名称"]&&e["净值日期"]){let t={fundId:e["唯一标识"]||m(),navDate:new Date(e["净值日期"]),unitNav:parseFloat(e["单位净值"])||0,cumulativeNav:parseFloat(e["累计净值"])||0,dailyReturn:parseFloat(e["日收益率"])||0,totalAssets:N(e["总规模"]),status:e["状态"]||"正常",recordTime:new Date(e["录入时间"]),cost:N(e["成本"]),marketValue:N(e["市值"]),positionChange:parseFloat(e["持仓变化"])||0};await a.insertNavHistory(t),s++}}return await x(a,{syncType:"excel_import",status:"success",recordsProcessed:s,recordsUpdated:i,syncStart:r,syncEnd:new Date}),f.NextResponse.json({success:!0,message:"数据同步成功",recordsProcessed:s,recordsUpdated:i,syncTime:r.toISOString()})}catch(t){console.error("数据同步失败:",t);let e=(0,A.getDatabase)();return await x(e,{syncType:"excel_import",status:"error",recordsProcessed:0,recordsUpdated:0,errorMessage:t instanceof Error?t.message:"未知错误",syncStart:new Date,syncEnd:new Date}),f.NextResponse.json({error:"数据同步失败: "+(t instanceof Error?t.message:"未知错误")},{status:500})}}async function v(){try{let e=(0,A.getDatabase)(),t=await new Promise((t,a)=>{e.db.get("SELECT * FROM sync_logs ORDER BY created_at DESC LIMIT 1",(e,r)=>{e?a(e):t(r)})});return f.NextResponse.json({success:!0,lastSync:t||null,databaseInitialized:!0})}catch(e){return console.error("获取同步状态失败:",e),f.NextResponse.json({error:"获取同步状态失败"},{status:500})}}function m(){return Date.now().toString(36)+Math.random().toString(36).substr(2)}function N(e){return e&&parseFloat(e.toString().replace(/[¥,]/g,"").replace(/,/g,""))||0}async function D(e){return{sheets:["私募基金盈利一览表","私募基金取数"],getSheet:e=>({data:[]})}}async function x(e,t){return new Promise((a,r)=>{let n=e.db.prepare(`
      INSERT INTO sync_logs (
        sync_type, status, records_processed, records_updated,
        error_message, sync_start, sync_end
      ) VALUES (?, ?, ?, ?, ?, ?, ?)
    `);n.run([t.syncType,t.status,t.recordsProcessed,t.recordsUpdated,t.errorMessage||null,t.syncStart.toISOString(),t.syncEnd.toISOString()],e=>{e?r(e):a()}),n.finalize()})}e.s(["GET",()=>v,"POST",()=>g],55655);var S=e.i(55655);let w=new t.AppRouteRouteModule({definition:{kind:a.RouteKind.APP_ROUTE,page:"/api/sync/route",pathname:"/api/sync",filename:"route",bundlePath:""},distDir:".next",relativeProjectDir:"",resolvedPagePath:"[project]/src/app/api/sync/route.ts",nextConfigOutput:"",userland:S}),{workAsyncStorage:I,workUnitAsyncStorage:L,serverHooks:b}=w;function O(){return(0,r.patchFetch)({workAsyncStorage:I,workUnitAsyncStorage:L})}async function C(e,t,r){w.isDev&&(0,n.addRequestMeta)(e,"devRequestTimingInternalsEnd",process.hrtime.bigint());let f="/api/sync/route";f=f.replace(/\/index$/,"")||"/";let A=await w.prepare(e,t,{srcPage:f,multiZoneDraftMode:!1});if(!A)return t.statusCode=400,t.end("Bad Request"),null==r.waitUntil||r.waitUntil.call(r,Promise.resolve()),null;let{buildId:g,params:v,nextConfig:m,parsedUrl:N,isDraftMode:D,prerenderManifest:x,routerServerContext:S,isOnDemandRevalidate:I,revalidateOnlyGenerated:L,resolvedPathname:b,clientReferenceManifest:O,serverActionsManifest:C}=A,F=(0,d.normalizeAppPath)(f),U=!!(x.dynamicRoutes[F]||x.routes[b]),M=async()=>((null==S?void 0:S.render404)?await S.render404(e,t,N,!1):t.end("This page could not be found"),null);if(U&&!D){let e=!!x.routes[b],t=x.dynamicRoutes[F];if(t&&!1===t.fallback&&!e){if(m.experimental.adapterPath)return await M();throw new y.NoFallbackError}}let P=null;!U||w.isDev||D||(P="/index"===(P=b)?"/":P);let H=!0===w.isDev||!U,k=U&&!H;C&&O&&(0,i.setReferenceManifestsSingleton)({page:f,clientReferenceManifest:O,serverActionsManifest:C,serverModuleMap:(0,o.createServerModuleMap)({serverActionsManifest:C})});let j=e.method||"GET",q=(0,s.getTracer)(),X=q.getActiveScopeSpan(),B={params:v,prerenderManifest:x,renderOpts:{experimental:{authInterrupts:!!m.experimental.authInterrupts},cacheComponents:!!m.cacheComponents,supportsDynamicResponse:H,incrementalCache:(0,n.getRequestMeta)(e,"incrementalCache"),cacheLifeProfiles:m.cacheLife,waitUntil:r.waitUntil,onClose:e=>{t.on("close",e)},onAfterTaskError:void 0,onInstrumentationRequestError:(t,a,r)=>w.onRequestError(e,t,r,S)},sharedContext:{buildId:g}},G=new l.NodeNextRequest(e),Y=new l.NodeNextResponse(t),V=u.NextRequestAdapter.fromNodeNextRequest(G,(0,u.signalFromNodeResponse)(t));try{let i=async e=>w.handle(V,B).finally(()=>{if(!e)return;e.setAttributes({"http.status_code":t.statusCode,"next.rsc":!1});let a=q.getRootSpanAttributes();if(!a)return;if(a.get("next.span_type")!==c.BaseServerSpan.handleRequest)return void console.warn(`Unexpected root span type '${a.get("next.span_type")}'. Please report this Next.js issue https://github.com/vercel/next.js`);let r=a.get("next.route");if(r){let t=`${j} ${r}`;e.setAttributes({"next.route":r,"http.route":r,"next.span_name":t}),e.updateName(t)}else e.updateName(`${j} ${f}`)}),o=!!(0,n.getRequestMeta)(e,"minimalMode"),d=async n=>{var s,d;let l=async({previousCacheEntry:a})=>{try{if(!o&&I&&L&&!a)return t.statusCode=404,t.setHeader("x-nextjs-cache","REVALIDATED"),t.end("This page could not be found"),null;let s=await i(n);e.fetchMetrics=B.renderOpts.fetchMetrics;let d=B.renderOpts.pendingWaitUntil;d&&r.waitUntil&&(r.waitUntil(d),d=void 0);let l=B.renderOpts.collectedTags;if(!U)return await (0,p.sendResponse)(G,Y,s,B.renderOpts.pendingWaitUntil),null;{let e=await s.blob(),t=(0,_.toNodeOutgoingHttpHeaders)(s.headers);l&&(t[R.NEXT_CACHE_TAGS_HEADER]=l),!t["content-type"]&&e.type&&(t["content-type"]=e.type);let a=void 0!==B.renderOpts.collectedRevalidate&&!(B.renderOpts.collectedRevalidate>=R.INFINITE_CACHE)&&B.renderOpts.collectedRevalidate,r=void 0===B.renderOpts.collectedExpire||B.renderOpts.collectedExpire>=R.INFINITE_CACHE?void 0:B.renderOpts.collectedExpire;return{value:{kind:h.CachedRouteKind.APP_ROUTE,status:s.status,body:Buffer.from(await e.arrayBuffer()),headers:t},cacheControl:{revalidate:a,expire:r}}}}catch(t){throw(null==a?void 0:a.isStale)&&await w.onRequestError(e,t,{routerKind:"App Router",routePath:f,routeType:"route",revalidateReason:(0,E.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:I})},S),t}},u=await w.handleResponse({req:e,nextConfig:m,cacheKey:P,routeKind:a.RouteKind.APP_ROUTE,isFallback:!1,prerenderManifest:x,isRoutePPREnabled:!1,isOnDemandRevalidate:I,revalidateOnlyGenerated:L,responseGenerator:l,waitUntil:r.waitUntil,isMinimalMode:o});if(!U)return null;if((null==u||null==(s=u.value)?void 0:s.kind)!==h.CachedRouteKind.APP_ROUTE)throw Object.defineProperty(Error(`Invariant: app-route received invalid cache entry ${null==u||null==(d=u.value)?void 0:d.kind}`),"__NEXT_ERROR_CODE",{value:"E701",enumerable:!1,configurable:!0});o||t.setHeader("x-nextjs-cache",I?"REVALIDATED":u.isMiss?"MISS":u.isStale?"STALE":"HIT"),D&&t.setHeader("Cache-Control","private, no-cache, no-store, max-age=0, must-revalidate");let c=(0,_.fromNodeOutgoingHttpHeaders)(u.value.headers);return o&&U||c.delete(R.NEXT_CACHE_TAGS_HEADER),!u.cacheControl||t.getHeader("Cache-Control")||c.get("Cache-Control")||c.set("Cache-Control",(0,T.getCacheControlHeader)(u.cacheControl)),await (0,p.sendResponse)(G,Y,new Response(u.value.body,{headers:c,status:u.value.status||200})),null};X?await d(X):await q.withPropagatedContext(e.headers,()=>q.trace(c.BaseServerSpan.handleRequest,{spanName:`${j} ${f}`,kind:s.SpanKind.SERVER,attributes:{"http.method":j,"http.target":e.url}},d))}catch(t){if(t instanceof y.NoFallbackError||await w.onRequestError(e,t,{routerKind:"App Router",routePath:F,routeType:"route",revalidateReason:(0,E.getRevalidateReason)({isStaticGeneration:k,isOnDemandRevalidate:I})}),U)throw t;return await (0,p.sendResponse)(G,Y,new Response(null,{status:500})),null}}e.s(["handler",()=>C,"patchFetch",()=>O,"routeModule",()=>w,"serverHooks",()=>b,"workAsyncStorage",()=>I,"workUnitAsyncStorage",()=>L],48455)}];

//# sourceMappingURL=%5Broot-of-the-server%5D__b8500329._.js.map