module.exports=[5472,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_strategy_page_actions_cc043697.js.map