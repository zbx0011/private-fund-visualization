module.exports=[65169,(e,o,d)=>{}];

//# sourceMappingURL=_next-internal_server_app_api_funds_%5Bid%5D_history_route_actions_1f715d25.js.map