module.exports = [
"[project]/.next-internal/server/app/api/funds/[id]/history/route/actions.js [app-rsc] (server actions loader, ecmascript)", ((__turbopack_context__, module, exports) => {

}),
];

//# sourceMappingURL=_next-internal_server_app_api_funds_%5Bid%5D_history_route_actions_1f715d25.js.map