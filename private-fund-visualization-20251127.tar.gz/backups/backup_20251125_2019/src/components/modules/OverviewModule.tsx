'use client'

import { useState, useEffect } from 'react'
import { MetricCard } from '@/components/ui/metric-card'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card'
import { YieldCurveChart } from '@/components/charts/YieldCurveChart'
import { StrategyDistributionChart } from '@/components/charts/StrategyDistributionChart'
import { formatCurrency } from '@/lib/utils'

import { ProfitAnalysisChart } from '@/components/charts/ProfitAnalysisChart'

const STRATEGY_TYPES = [
    '指增',
    '中性',
    'CTA',
    'T0',
    '套利',
    '量选',
    '混合',
    '期权',
    '择时对冲',
    '可转债'
]

interface OverviewModuleProps {
    initialData?: any
    initialLoading?: boolean
    initialError?: string | null
}

export function OverviewModule({ initialData, initialLoading = false, initialError }: OverviewModuleProps) {
    const [data, setData] = useState<any>(initialData)
    const [loading, setLoading] = useState(initialLoading)
    const [selectedStrategy, setSelectedStrategy] = useState<string>('all')
    const [monitorData, setMonitorData] = useState<any[]>([])

    // Fetch full history data when component mounts
    useEffect(() => {
        const loadFullData = async () => {
            try {
                setLoading(true)

                // Fetch monitor data
                const monitorRes = await fetch('/api/monitor?limit=50')
                const monitorJson = await monitorRes.json()
                if (monitorJson.success) {
                    setMonitorData(monitorJson.data)
                }

                const res = await fetch('/api/funds?type=excluded-fof&includeHistory=true')
                const json = await res.json()
                if (json.success) {
                    const { funds, strategyStats, managerStats } = json.data

                    // Filter funds by status
                    // 只要不是已赎回状态，都视为正常参与计算
                    const normalFunds = funds.filter((f: any) => f.status !== '已赎回')

                    // Calculate aggregated metrics
                    // 1. 总规模: 产品数据的成本列的总和 (仅计算正常状态产品，排除已赎回)
                    const totalAssets = normalFunds.reduce((sum: number, f: any) => sum + (f.cost || 0), 0)

                    // 2. 总日均资金占用: 飞书多维表格的私募盈亏一览表的日均资金占用列的总和 (包含所有产品)
                    const totalDailyCapitalUsage = funds.reduce((sum: number, f: any) => sum + (f.daily_capital_usage || 0), 0)

                    // 3. 今日收益: 产品数据的本日收益列的总和 (仅计算正常状态产品)
                    const todayReturn = normalFunds.reduce((sum: number, f: any) => sum + (f.daily_pnl || 0), 0)

                    // 4. 本周收益率: 飞书多维表格私募盈亏一览表的本周收益列的总和/总规模*100%
                    // 注意：这里也应该只计算正常产品的本周收益，以与总规模匹配
                    const totalWeeklyPnl = normalFunds.reduce((sum: number, f: any) => sum + (f.weekly_pnl || 0), 0)
                    const weeklyReturn = totalAssets ? totalWeeklyPnl / totalAssets : 0

                    // 5. 本年收益率: 飞书多维表格私募盈亏一览表的本年收益列的总和/总日均资金占用*100%
                    const totalYearlyPnl = funds.reduce((sum: number, f: any) => sum + (f.yearly_pnl || 0), 0)
                    const annualReturn = totalDailyCapitalUsage ? totalYearlyPnl / totalDailyCapitalUsage : 0

                    // Map strategy stats
                    const strategyData = strategyStats
                        .filter((s: any) => !['择时', '宏观'].includes(s.strategy))
                        .map((s: any) => ({
                            strategy: s.strategy,
                            value: s.total_cost || 0,
                            count: s.fund_count
                        }))

                    setData({
                        funds,
                        strategyStats,
                        managerStats,
                        totalAssets,
                        totalDailyCapitalUsage,
                        todayReturn,
                        weeklyReturn,
                        annualReturn,
                        strategyData,
                        lastSyncTime: json.data.lastSyncTime
                    })
                }
            } catch (err) {
                console.error('Failed to load full history:', err)
            } finally {
                setLoading(false)
            }
        }
        loadFullData()
    }, [])

    if (loading) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="text-center">
                    <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
                    <p className="text-gray-600">正在加载数据...</p>
                </div>
            </div>
        )
    }

    if (initialError || !data) {
        return (
            <div className="flex items-center justify-center h-96">
                <div className="text-center">
                    <div className="text-red-600 text-6xl mb-4">⚠️</div>
                    <p className="text-gray-600 text-lg mb-4">{initialError || '数据加载失败'}</p>
                </div>
            </div>
        )
    }

    // Helper to get the Friday of the week for a given date
    const getWeekEndingDate = (dateStr: string) => {
        const date = new Date(dateStr)
        const day = date.getDay()
        const diff = date.getDate() - day + (day === 0 ? -2 : 5) // Adjust to Friday
        const friday = new Date(date.setDate(diff))
        return friday.toISOString().split('T')[0]
    }

    // Process data for the chart
    const getChartData = () => {
        if (!data.funds) return { chartData: [], series: [] }

        // Filter funds based on selected strategy
        const filteredFunds = selectedStrategy === 'all'
            ? data.funds
            : data.funds.filter((f: any) => f.strategy === selectedStrategy)

        // ---------------------------------------------------------
        // Scenario 1: "All Strategies" - Aggregate by Strategy
        // ---------------------------------------------------------
        if (selectedStrategy === 'all') {
            // We will collect data into a map: Date -> { Strategy -> { sumReturn, sumYearly, count } }
            const weeklyMap = new Map<string, {
                date: string,
                strategies: Map<string, { sumReturn: number, sumYearly: number, count: number }>
            }>()

            data.funds.forEach((fund: any) => {
                if (!fund.strategy) return
                if (['择时', '宏观'].includes(fund.strategy)) return
                if (!fund.history || fund.history.length === 0) return

                // Filter for 2025 data
                const history2025 = fund.history
                    .filter((h: any) => h.date >= '2025-01-01')
                    .sort((a: any, b: any) => a.date.localeCompare(b.date))

                if (history2025.length === 0) return

                const baseNav = history2025[0].cumulative_nav

                // 1. Identify the value for each week for this fund (take the last available day of the week)
                const fundWeeklyValues = new Map<string, any>()
                history2025.forEach((h: any) => {
                    const dateStr = h.date.split('T')[0]
                    const weekDate = getWeekEndingDate(dateStr)

                    // Overwrite: later days in the week will replace earlier ones
                    fundWeeklyValues.set(weekDate, {
                        cumulative_nav: h.cumulative_nav,
                        daily_return: h.daily_return || 0
                    })
                })

                // 2. Add this fund's weekly values to the global aggregation
                fundWeeklyValues.forEach((val, weekDate) => {
                    if (!weeklyMap.has(weekDate)) {
                        weeklyMap.set(weekDate, { date: weekDate, strategies: new Map() })
                    }
                    const weekData = weeklyMap.get(weekDate)!

                    if (!weekData.strategies.has(fund.strategy)) {
                        weekData.strategies.set(fund.strategy, { sumReturn: 0, sumYearly: 0, count: 0 })
                    }
                    const stratStats = weekData.strategies.get(fund.strategy)!

                    const normalizedReturn = baseNav ? (val.cumulative_nav - baseNav) / baseNav : 0

                    stratStats.sumReturn += normalizedReturn
                    stratStats.sumYearly += normalizedReturn
                    stratStats.count += 1
                })
            })

            // 3. Flatten map to chartData array
            const chartData = Array.from(weeklyMap.values())
                .map(item => {
                    const point: any = { date: item.date }
                    item.strategies.forEach((stats, strategy) => {
                        point[strategy] = stats.sumReturn / stats.count
                        point[`${strategy}_yearly`] = stats.sumYearly / stats.count
                    })
                    return point
                })
                .sort((a, b) => a.date.localeCompare(b.date))

            // 4. Build Series
            const strategyColors: Record<string, string> = {
                '指增': '#3b82f6',
                '中性': '#10b981',
                'CTA': '#f59e0b',
                'T0': '#8b5cf6',
                '套利': '#ec4899',
                '量选': '#06b6d4',
                '混合': '#f97316',
                '期权': '#6366f1',
                '择时对冲': '#8b5cf6',
                '可转债': '#d946ef'
            }

            const series = Array.from(new Set(data.funds.map((f: any) => f.strategy).filter(Boolean))).map((strategy: any) => ({
                id: strategy,
                name: strategy,
                color: strategyColors[strategy] || `hsl(${Math.random() * 360}, 70%, 50%)`,
                strokeWidth: 2.5,
                yearlyKey: `${strategy}_yearly`
            }))

            return { chartData, series }
        }

        // ---------------------------------------------------------
        // Scenario 2: Specific Strategy - Individual Funds
        // ---------------------------------------------------------
        const weeklyMap = new Map<string, any>()

        filteredFunds.forEach((fund: any) => {
            if (!fund.history || fund.history.length === 0) return

            const history2025 = fund.history
                .filter((h: any) => h.date >= '2025-01-01')
                .sort((a: any, b: any) => a.date.localeCompare(b.date))

            if (history2025.length === 0) return

            const baseNav = history2025[0].cumulative_nav

            // Group by week
            history2025.forEach((h: any) => {
                const dateStr = h.date.split('T')[0]
                const weekDate = getWeekEndingDate(dateStr)

                if (!weeklyMap.has(weekDate)) {
                    weeklyMap.set(weekDate, { date: weekDate })
                }
                const point = weeklyMap.get(weekDate)

                // Use the latest value for the week (since we iterate sorted by date, this naturally happens)
                const normalizedReturn = baseNav ? (h.cumulative_nav - baseNav) / baseNav : 0

                point[fund.record_id] = normalizedReturn
                point[`${fund.record_id}_yearly`] = normalizedReturn
            })
        })

        const chartData = Array.from(weeklyMap.values()).sort((a, b) => a.date.localeCompare(b.date))

        const series = filteredFunds.map((fund: any) => ({
            id: fund.record_id,
            name: fund.name,
            color: `hsl(${Math.random() * 360}, 70%, 50%)`,
            strokeWidth: 2,
            yearlyKey: `${fund.record_id}_yearly`
        }))

        return { chartData, series }
    }

    const { chartData, series } = getChartData()

    return (
        <div className="space-y-4">
            {/* 1. 核心指标 */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-5 gap-3">
                <MetricCard
                    title="总规模"
                    value={data.totalAssets}
                    format="currency"
                    className="col-span-1"
                />
                <MetricCard
                    title="总日均资金占用"
                    value={data.totalDailyCapitalUsage}
                    format="currency"
                    className="col-span-1"
                />
                <MetricCard
                    title="今日收益"
                    value={data.todayReturn}
                    format="currency"
                    className="col-span-1"
                />
                <MetricCard
                    title="七天内收益率"
                    value={data.weeklyReturn}
                    format="percent"
                    className="col-span-1"
                />
                <MetricCard
                    title="本年收益率"
                    value={data.annualReturn}
                    format="percent"
                    className="col-span-1"
                />
            </div>

            {/* 2. 近期事件提示 */}
            <Card>
                <CardHeader className="py-2">
                    <CardTitle className="text-sm text-gray-900">🔔 近期事件提示</CardTitle>
                </CardHeader>
                <CardContent className="py-2">
                    <div className="flex flex-wrap gap-2">
                        {/* 1. 外部信息监控中一周内有负面消息的 */}
                        {monitorData
                            .filter((m: any) => {
                                const isNegative = m.sentiment === '负面'
                                // Use m.date as the source of truth, fallback to created_at if needed
                                const dateStr = m.date || m.created_at
                                if (!dateStr) return false

                                const date = new Date(dateStr)
                                const oneWeekAgo = new Date()
                                oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)
                                // Reset time part for accurate date comparison
                                oneWeekAgo.setHours(0, 0, 0, 0)

                                return isNegative && date >= oneWeekAgo
                            })
                            .map((m: any, i: number) => (
                                <a
                                    key={`monitor-${i}`}
                                    href={m.url}
                                    target="_blank"
                                    rel="noopener noreferrer"
                                    className="px-3 py-1.5 bg-red-100 border border-red-200 rounded-md text-red-800 text-xs font-medium flex items-center shadow-sm hover:bg-red-200 transition-colors cursor-pointer"
                                >
                                    <span className="mr-1">📢</span>
                                    <span>负面: {m.title} ({m.date})</span>
                                </a>
                            ))}

                        {/* 2. 产品数据中本日收益大于十万或者亏损大于十万（也就是小于-10万）的产品 */}
                        {data.funds
                            .filter((f: any) => f.status !== '已赎回' && Math.abs(f.daily_pnl) > 100000)
                            .map((f: any, i: number) => (
                                <div
                                    key={`pnl-${i}`}
                                    className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center shadow-sm border ${f.daily_pnl > 0
                                        ? 'bg-red-50 border-red-100 text-red-700'
                                        : 'bg-green-50 border-green-100 text-green-700'
                                        }`}
                                >
                                    <span className="mr-1">{f.daily_pnl > 0 ? '📈' : '📉'}</span>
                                    <span>{f.name} ({formatCurrency(f.daily_pnl)})</span>
                                </div>
                            ))}

                        {/* 3. 产品数据中集中度大于10%的产品（不包括比说碧烁太极二号） */}
                        {data.funds
                            .filter((f: any) => f.status !== '已赎回' && f.concentration > 0.1 && f.name !== '碧烁太极二号')
                            .map((f: any, i: number) => (
                                <div key={`conc-${i}`} className="px-3 py-1.5 bg-amber-50 border border-amber-200 rounded-md text-amber-800 text-xs font-medium flex items-center shadow-sm">
                                    <span className="mr-1">⚠️</span>
                                    <span>高集中度: {f.name} ({(f.concentration * 100).toFixed(2)}%)</span>
                                </div>
                            ))}

                        {/* 4. 出现当日的某类策略收益大于30万或者亏损大于30万（也就是小于-30万） */}
                        {(() => {
                            const strategyPnl = new Map<string, number>()
                            data.funds.forEach((f: any) => {
                                if (f.status !== '已赎回' && f.strategy && f.daily_pnl) {
                                    strategyPnl.set(f.strategy, (strategyPnl.get(f.strategy) || 0) + f.daily_pnl)
                                }
                            })
                            return Array.from(strategyPnl.entries())
                                .filter(([_, pnl]) => Math.abs(pnl) > 300000)
                                .map(([strategy, pnl], i) => (
                                    <div
                                        key={`strat-${i}`}
                                        className={`px-3 py-1.5 rounded-md text-xs font-medium flex items-center shadow-sm border ${pnl > 0
                                            ? 'bg-orange-50 border-orange-100 text-orange-700'
                                            : 'bg-blue-50 border-blue-100 text-blue-700'
                                            }`}
                                    >
                                        <span className="mr-1">{pnl > 0 ? '🚀' : '🌊'}</span>
                                        <span>策略{pnl > 0 ? '大涨' : '大跌'}: {strategy} ({formatCurrency(pnl)})</span>
                                    </div>
                                ))
                        })()}

                        {/* Fallback if no events */}
                        {(!monitorData.some((m: any) => {
                            const dateStr = m.date || m.created_at
                            if (!dateStr) return false
                            const date = new Date(dateStr)
                            const oneWeekAgo = new Date()
                            oneWeekAgo.setDate(oneWeekAgo.getDate() - 7)
                            oneWeekAgo.setHours(0, 0, 0, 0)
                            return m.sentiment === '负面' && date >= oneWeekAgo
                        }) &&
                            !data.funds.some((f: any) => f.status !== '已赎回' && Math.abs(f.daily_pnl) > 100000) &&
                            !data.funds.some((f: any) => f.status !== '已赎回' && f.concentration > 0.1 && f.name !== '碧烁太极二号') &&
                            !Array.from(new Set(data.funds.map((f: any) => f.strategy))).some((s: any) => Math.abs(data.funds.filter((f: any) => f.status !== '已赎回' && f.strategy === s).reduce((sum: number, f: any) => sum + (f.daily_pnl || 0), 0)) > 300000)
                        ) && (
                                <div className="text-gray-500 text-xs italic px-2">暂无重要事件提示</div>
                            )}
                    </div>
                </CardContent>
            </Card>

            {/* 3. 收益比较 */}
            <ProfitAnalysisChart funds={data.funds} lastSyncTime={data.lastSyncTime} />

            {/* 4. 收益率曲线 */}
            <Card>
                <CardHeader>
                    <div className="flex flex-col space-y-4 w-full">
                        <div className="flex items-center justify-between">
                            <CardTitle>📈 收益率曲线</CardTitle>
                        </div>
                        <div className="flex flex-wrap gap-2">
                            <button
                                onClick={() => setSelectedStrategy('all')}
                                className={`px-3 py-1 text-sm rounded-full transition-colors ${selectedStrategy === 'all'
                                    ? 'bg-blue-600 text-white'
                                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                    }`}
                            >
                                全部策略
                            </button>
                            {STRATEGY_TYPES.map((strategy) => (
                                <button
                                    key={strategy}
                                    onClick={() => setSelectedStrategy(strategy)}
                                    className={`px-3 py-1 text-sm rounded-full transition-colors ${selectedStrategy === strategy
                                        ? 'bg-blue-600 text-white'
                                        : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                                        }`}
                                >
                                    {strategy}
                                </button>
                            ))}
                        </div>
                    </div>
                </CardHeader>
                <CardContent>
                    <YieldCurveChart data={chartData} series={series} />
                </CardContent>
            </Card>

            {/* 5. 策略分布 */}
            <Card>
                <CardHeader>
                    <CardTitle className="text-gray-900">🥧 策略分布</CardTitle>
                </CardHeader>
                <CardContent>
                    {data.strategyData && data.strategyData.length > 0 ? (
                        <StrategyDistributionChart data={data.strategyData} />
                    ) : (
                        <div className="h-[300px] flex items-center justify-center text-gray-400">
                            暂无策略分布数据
                        </div>
                    )}
                </CardContent>
            </Card>
        </div>
    )
}
